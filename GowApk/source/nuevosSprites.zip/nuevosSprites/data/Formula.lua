function HeroHPValue(level) ---主角血量成长公式	
	return level*100+1900;  
end

function HeroMPValue(level) ---主角蓝量成长公式
	return level*5+195;
end

function HeroAttackValue(level) ---主角攻击成长公式
	return level*8+42;
end

function HeroMapValue(level) ---主角魔法攻击成长公式
	return level*9+46;
end

function HeroDefValue(level) ---主角防御成长公式
	return level*8+40;
end

function HeroCritValue(level) ---主角暴击成长公式
	return level*2+23;
end

function HeroExpValue(level) ---主角经验成长公式
	return level*level*8+58*level+153;
end

function getHeroAttackDiffrentStageIndex(weaponType,state)
local attackIndex = 1.0
	if weaponType == 1 then --拳套武器
		if state == 24 then --普攻第一下<24 乐堂精灵状态>
			attackIndex = 0.8
		elseif state == 26 then --普攻第二下<24 乐堂精灵状态>
			attackIndex = 1.0
		elseif state == 27 then --普攻第三下<24 乐堂精灵状态>
			attackIndex = 1.3
		end
	else
		if state == 24 then --普攻第一下<24 乐堂精灵状态>
			attackIndex = 0.5
		elseif state == 25 then --普攻第二下<24 乐堂精灵状态>
			attackIndex = 0.9
		elseif state == 26 then --普攻第三下<24 乐堂精灵状态>
			attackIndex = 1.3
		elseif state == 27 then --普攻第四下<24 乐堂精灵状态>
			attackIndex = 1.8
		end
	end
	return attackIndex
end

function HeroFightValue(level) ---主角总战斗力成长公式 参数<level 当前主角等级>
----------------主角战斗力---------------------------
	att = HeroAttackValue(level)*8 --- 攻击
	matt = HeroMapValue(level)*8----魔法攻击
	defen = HeroDefValue(level)*4  --- 防御
	crit = HeroCritValue(level)*3  --- 暴击
	maxHP = HeroHPValue(level)/3   --- 最大血量
	maxMP = HeroMPValue(level) --- 最大能量
	herofight = att + matt + defen + crit + maxHP  + maxMP + 850
	return herofight;
end

function HeroWeaponFightValue(weaponType,weaponLevel) ---主角总战斗力成长公式 参数< weaponType 当前武器类型,weaponLevel 当前武器等级>	
----------------武器战斗力---------------------------	
	weaponAtt = HeroWeaponAttack(weaponType,weaponLevel)*8 --- 武器攻击力
	weaponMatt = HeroWeaponMicAttack( weaponType, weaponLevel)*8;
	weaponDef = HeroWeaponDef(weaponType,weaponLevel)*4 --- 武器防御力
	weaponCrit = HeroWeaponCrit(weaponType,weaponLevel)*3 --- 武器暴击率
	weaponHP = HeroWeaponHP(weaponType,weaponLevel)/3 -- 武器生命上限
	weaponFight = (weaponAtt + weaponMatt + weaponDef + weaponCrit + weaponHP )	
	return weaponFight;
end

function HeroSkillCDTimeValue(level,mode) ---- 主角技能CD时间(level 技能等级, mode技能类型 (0技能A ,1技能B ,2技能C))	
local skillTime = 0
	if(mode == 0)then
		skillTime = 8.0 - ((level- 1) * 0.10)			
	elseif(mode == 1)then
		skillTime = 15.0 - ((level- 1) * 0.20)		
	elseif(mode == 2)then
		skillTime = 25.0 - ((level- 1) * 0.20)			
	end   	
	return skillTime;
end

function HeroSkillCDTimeDistanceValue(mode) ---- 主角技能CD时间成长系数	
local skillTime = 0
	if(mode == 0)then
		skillTime = 0.10		
	elseif(mode == 1)then
		skillTime = 0.20		
	elseif(mode == 2)then
		skillTime = 0.20		
	end   	
	return skillTime;
end

function SkillDPSDistanceValue(level,mode,maxAttack) ---技能升级伤害系数 (0技能A ,1技能B ,2技能C))		
	local lastLevel = level - 1;	
	local currentValue = SkillDPSValue(level,mode) * maxAttack;
	local lastValue = SkillDPSValue(lastLevel,mode) * maxAttack;	
	
	local integer,dismodf   = math.modf(currentValue);
	local integer1,dismodf1 = math.modf(lastValue);
	return integer - integer1;
end

function HeroSkillSubChakra(mode,level) ---- 主角技能能量消耗(level 技能等级, mode技能类型 (0技能A ,1技能B ,2技能C))	
	if(mode == 0)then			
		return level*2 + 35; 
	elseif(mode == 1)then		 
		return level*3 + 75; 
	elseif(mode == 2)then	
		return level*3 + 85; 
	end   	
	return 0;
end

function getHeroPerSecondsOfMP() --获得主角每秒恢复蓝量的数值
	return 1;
end


function HeroWeaponLvUpProplity(level,mode) -------主角武器升级概率(level 武器等级 , mode 星级阶段) 	
	if mode == 0 then ---第一阶段
		return 100 - ((level- 1) * 5);
	elseif mode == 1 then ---第二阶段
		return 90 - ((level- 1) * 5);
	elseif mode == 2 then ---第三阶段
		return 80 - ((level- 1) * 5);
	elseif mode == 3 then ---第四阶段
		return 70 - ((level- 1) * 5);
	elseif mode == 4 then ---第五阶段
		return 60 - ((level- 1) * 5);
	end
	return 0;
end

function HeroWeaponAttack(weaponType,level) -------主角武器攻击力成长公式(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then ----第一把武器
		return level*12+200;
	elseif weaponType == 1 then ----第二把武器
		return level*25+300;
	elseif weaponType == 2 then ----第三把武器
		return 0;
	elseif weaponType == 3 then ----第四把武器
		return level*42+500;
	end
	return 0;
end

function HeroWeaponMicAttack(weaponType,level) -------主角武器魔法攻击力成长公式(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 0;
	elseif weaponType == 1 then
		return 0;
	elseif weaponType == 2 then
		return level*28+360;
	elseif weaponType == 3 then
		return level*45+530;
	end
	return 0;
end

function HeroWeaponDef(weaponType,level) -------主角武器防御成长公式(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 0;
	elseif weaponType == 1 then
		if level < 11 then
			return 0;
		elseif 	level > 10	and  level < 31  then
			return (level-10)*4+12;
		end
	elseif weaponType == 2 then
		return 0;
	elseif weaponType == 3 then
		return level*5+57;
	end
	return 0;
end

function HeroWeaponHP(weaponType,level) -------主角武器生命成长公式(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 0;
	elseif weaponType == 1 then		
		return level*21+135;
	elseif weaponType == 2 then
		if level < 11 then 
			return 0;
		elseif  level > 10	and  level < 31  then
			return (level-10)*41+211;
		end
	elseif weaponType == 3 then
		return level*52+260;		
	end
	return 0;
end

function HeroWeaponCrit(weaponType,level) -------主角武器暴击成长公式(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		if level < 11 then
			return 0
		end
		return (level-10)*4+12;
	elseif weaponType == 1 then
		return 0;
	elseif weaponType == 2 then
		return  level*6+15;
	elseif weaponType == 3 then
		return  level*5+23;
	end
	return 0;
end

function HeroWeaponUIMaxAttack(weaponType) -------主角武器攻击力UI显示最大值(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then ----第一把武器
		return 800;
	elseif weaponType == 1 then ----第二把武器
		return 1235;
	elseif weaponType == 2 then ----第三把武器
		return 1;
	elseif weaponType == 3 then ----第四把武器
		return 2450;
	end
	return 0;
end

function HeroWeaponMicUIMaxAttack(weaponType) -------主角武器魔法攻击力UI显示最大值(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 1;
	elseif weaponType == 1 then
		return 1;
	elseif weaponType == 2 then
		return 1333;
	elseif weaponType == 3 then
		return 2400;
	end
	return 0;
end

function HeroWeaponUIMaxDef(weaponType) -------主角武器防御UI显示最大值(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 1;
	elseif weaponType == 1 then
		return  449;
	elseif weaponType == 2 then
		return 1;
	elseif weaponType == 3 then
		return 467;
	end
	return 0;
end

function HeroWeaponUIMaxHP(weaponType) -------主角武器生命UI显示最大值(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 1;
	elseif weaponType == 1 then		
		return 1275;
	elseif weaponType == 2 then
		return 1586;
	elseif weaponType == 3 then
		return 3120;		
	end
	return 0;
end

function HeroWeaponUIMaxCrit(weaponType) -------主角武器暴击UI显示最大值(weaponType 武器类型 ,level 武器等级)
	if weaponType == 0 then
		return 204;
	elseif weaponType == 1 then
		return 1;
	elseif weaponType == 2 then
		return  390;
	elseif weaponType == 3 then
		return  495;
	end
	return 0;
end

function WeaponLvUpStarMoney(weaponType,level) ----武器升星所需金币
	if weaponType == 0 then
		return 30 + level * 7;
	elseif weaponType == 1 then
		return 50 + level * 8;
	elseif weaponType == 2 then
		return 70 + level * 9;
	elseif weaponType == 3 then
		return 90 + level * 11;
	end
	return 0;
end

function WeaponLvUpSouls(weaponType,level) ----武器升级所需红魂
	if weaponType == 0 then
		return 50 + level * 90;
	elseif weaponType == 1 then
		return 100 + level * 110;
	elseif weaponType == 2 then
		return 150 + level * 130;
	elseif weaponType == 3 then
		return 400 + level * 180;
	end
	return 0;
end

function SkillDPSValue(level,mode) ---技能升级伤害系数公式(level 技能等级, mode技能类型 (0技能A ,1技能B ,2技能C))		
	if(mode == 0)then		
		return math.pow(level,2)*0.000863 + level*0.056 + 1.043137;
	elseif(mode == 1)then		
		return math.pow(level,2)*0.000751 + level*0.025 + 1.074249;
	elseif(mode == 2)then			
		return math.pow(level,2)*0.000307 + level*0.056 + 1.043693;
	end
	return 0;
end

---技能升级消耗金币成长公式(level 技能等级, mode技能类型(0技能A ,1技能B ,2技能C)) （11-30）
function SkillSubMoneyValue(level,mode) 		
	if(mode == 0)then
		return level*10 + 90;
	elseif(mode == 1)then
		return level*12 + 98;
	elseif(mode == 2)then	
		return level*20 +100;
	end
	return 0;
end

---技能升级消耗红魂成长公式(level 技能等级, mode技能类型 (0技能A ,1技能B ,2技能C))	（1-10）
function SkillSubSoulsValue(level,mode) 	
	if(mode == 0)then
		return level*15 + 285;
	elseif(mode == 1)then
		return level*20 + 480;
	elseif(mode == 2)then	
		return level*50 + 550;
	end
	return 0;
end

function getFightRewardMoney(MaxRank,currentRank)---变“20”可以调节奖励的数额大小，战斗力排行榜奖励。
	local money = 0
	if MaxRank <= currentRank then
		return money;
	  end	  
	money = (MaxRank - currentRank) * 20
		return money;
end

---千层塔宝箱开启奖励货币 (pices 塔层数,  moneyType 货币类型 0金币 1红魂)
function  getHuperziaBoxRewardMoney(pices,moneyType)
	if moneyType == 0 then
		return 10 * pices + 5;
	 end
	 return 40 * pices + 30;
end

----周卡返利每日奖励金币
function getWeaklyCardMoney(currentDay)
	if currentDay == 0 then
		return 1250;
	elseif currentDay == 1 then
		return 1050;
	elseif currentDay == 2 then
		return 1350;
	elseif currentDay == 3 then
		return 1400;
	elseif currentDay == 4 then
		return 1250;
	elseif currentDay == 5 then
		return 1100;
	elseif currentDay == 6 then
		return 1600;
	end
end
---拳套、电光链武器金币价格公式
function getWeaponMoney(weaponType,debrisNumber)--weaponType武器类型 ,debrisNumber武器当前碎片数量
	if weaponType == 1 then --拳套
		return 1500 - (debrisNumber * 500);
	elseif weaponType == 2 then --电光链
		return 3600 - (debrisNumber * 400);
		end	
end
---离线奖励<经验、红魂、消耗金币> ,VIP 130% 领取 VIPType<0是普通, 1是VIP>
function getOffLineReward(heroLevel,rewardType,VIPType)
	local exps = heroLevel * 60 + 30
	local souls = heroLevel * 80 + 520
	local subMoney = heroLevel * 16 + 50
	
	if rewardType == 0 then --经验
        if VIPType == 1 then
           exps = exps + exps * 3 / 10
           return exps;
        end      
		return exps;
	elseif rewardType == 1 then --红魂、消耗金币
        if VIPType == 1 then
           souls = souls + souls * 3 / 10
           return souls;
        end      		
		return souls;
	elseif rewardType == 2 then --消耗金币		
		return subMoney;
		end	
	return 0;
end

----VIP每日签到奖励金币
function getEveryDaySignVIPMoney(currentDay)
	if currentDay == 1 then
		return 100;
	elseif currentDay == 2 then
		return 140;
	elseif currentDay == 3 then
		return 120;
	elseif currentDay == 4 then
		return 160;
	elseif currentDay == 5 then
		return 200;	
	end
end

---扫荡消耗金币
function sweepingSubMoney(sweepingTimes)
	if sweepingTimes > 6 then --超过10次 最大为80金币
		return 150;
	end
	return sweepingTimes*20 + 10;
end

---赚金币副本奖励金币
function getMakeMoneyDropMoney(heroLv)
	return heroLv * 8;
end

---取红魂副本奖励红魂
function getMakeRedSoulDropSouls(heroLv)
	return heroLv * 90;
end