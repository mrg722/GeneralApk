--region GateTask.lua
--Date 2015/12/15
--此文件由[BabeLua]插件自动生成

--[[local item = {
	{itemType=1,Name="生命药",},
	{itemType=2,Name="能量药",},
	{itemType=3,Name="金币",},
	{itemType=4,Name="红魂",},
	{itemType=5,Name="经验",},
	{itemType=6,Name="拳套碎片1",},
	{itemType=7,Name="拳套碎片2",},
	{itemType=8,Name="拳套碎片3",},
	{itemType=9,Name="电光链碎片1",},
	{itemType=10,Name="电光链碎片2",},
	{itemType=11,Name="电光链碎片3",},
	{itemType=12,Name="电光链碎片4",},
	{itemType=13,Name="电光链碎片5",},
	{itemType=14,Name="电光链碎片6",},
}]]

lenrow = 7
lenline = 9
------第几天宝箱, 物品类型,物品数量,.........
data = {
    {1,  4,1000,  1,3,  2,3,  0,0,},
	{0,  0,	0,  0,0,  0,0,  0,0,},
    {3,  4,2000,  3,150,  1,4,   0,0,},
	{0,  0,0,  0,0,  0,0,  0,0,},
    {5,  3,220,  2,4,  1,5,   0,0,},
	{0,  0,0,  0,0,  0,0,  0,0,},
    {7,  4,3000,  3,250,  2,6,  1,6,},   
}

--endregion
