﻿appID = "a01"
channelID = "a01"
gameVision = ""