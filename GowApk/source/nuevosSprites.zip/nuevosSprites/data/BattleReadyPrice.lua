
MoneyType = {
{mType = 1,moneyName = "人民币",},
{mType = 2,moneyName = "红魂",},
{mType = 3,moneyName = "金币",},
}

PriceData = {
{Type = 1,  Name = "伤害加深",		   				OneTime = true,  priceType = 3,	Money = 180,},
{Type = 2,  Name = "获得药品", 		            	OneTime = false, priceType = 3,	Money = 240,},
{Type = 3,  Name = "收益加成", 		    			OneTime = true,  priceType = 3,	Money = 120,},
{Type = 4,  Name = "试用武器1（物攻）", 			OneTime = true,  priceType = 2, Money = 1800},
{Type = 5,  Name = "试用武器2（魔攻）", 			OneTime = true,  priceType = 3, Money = 220,},
{Type = 6,  Name = "试用武器3（双修）", 			OneTime = true,  priceType = 3, Money = 280,},
{Type = 7,  Name = "暴击提升", 						OneTime = true,  priceType = 2, Money = 600,},
{Type = 8,  Name = "神秘宝箱", 						OneTime = false, priceType = 2, Money = 880,},
{Type = 9,  Name = "神速", 							OneTime = true,  priceType = 3, Money = 120,},
{Type = 10, Name = "肉盾", 							OneTime = true,  priceType = 3,	Money = 160,},
{Type = 11, Name = "获得武器1", 					OneTime = true,  priceType = 1,	Money = -1,},
{Type = 12, Name = "获得武器2", 					OneTime = true,  priceType = 1,	Money = -1,},
{Type = 13, Name = "获得武器3", 					OneTime = true,  priceType = 1,	Money = -1,},
{Type = 14, Name = "战意", 							OneTime = true,  priceType = 3, Money = 260,},
}
---序号(ID)	1 伤害加深 ,2 获得药品 ,3 收益加成 4, 试用武器1（物攻） 5,试用武器2（魔攻） 6,试用武器3（双修） 7,暴击提升 8,神秘宝箱 9,神速 10,肉盾 11,获得武器1 12,获得武器2 13,获得武器3 14,战意 15,关卡号

function getPriceDataLength() --数组长度（物品个数）
  return table.getn(PriceData);
end

function getItemID(id) ----物品类型
  itemType = PriceData[id].Type
	return itemType
end

function getItemName(id) ----物品名称
    PriceName = PriceData[id].Name
	return PriceName
end

function isOneTimes(id)---是否限购一次
   oneTimes = PriceData[id].OneTime
   return oneTimes;
end

function getPriceType(id)---计费点类型priceType 货币类型 0 RMB 1 红魂 2金币
   itemPriceType = PriceData[id].priceType
   priceMoneyType = MoneyType[itemPriceType].mType
   return priceMoneyType;
end

function getPriceMoney(id) ----物品价格 id 物品类型
  priceMoney = PriceData[id].Money
    return priceMoney;
end