
local item = {
	{itemType=1,Name="生命药",},
	{itemType=2,Name="能量药",},
	{itemType=3,Name="金币",},
	{itemType=4,Name="红魂",},
	{itemType=5,Name="经验",},
	{itemType=6,Name="碎片2-1",},
	{itemType=7,Name="碎片2-2",},
	{itemType=8,Name="碎片2-3",},
	{itemType=9,Name="碎片3-1",},
	{itemType=10,Name="碎片3-2",},
	{itemType=11,Name="碎片3-3",},
	{itemType=12,Name="碎片3-4",},
	{itemType=13,Name="碎片3-5",},
	{itemType=14,Name="碎片3-6",},
}

--ItemAwards1 ItemAwards2 ItemAwards3 道具类型|  ItemNumeber1 ItemNumeber2 ItemNumeber2 道具数量
local starAwards = {
	{StarBox = 1,Star=15,ItemAwards1 = 2,ItemAwards2 = 4,ItemAwards3 = 0,ItemNumeber1 = 2,ItemNumeber2 = 200,ItemNumeber3 = 0,},
	{StarBox = 2,Star=30,ItemAwards1 = 1,ItemAwards2 = 3,ItemAwards3 = 0,ItemNumeber1 = 3,ItemNumeber2 = 150,ItemNumeber3 = 0,},
	{StarBox = 3,Star=15,ItemAwards1 = 1,ItemAwards2 = 14,ItemAwards3 = 0,ItemNumeber1 = 4,ItemNumeber2 = 1,ItemNumeber3 = 0,},
	{StarBox = 4,Star=30,ItemAwards1 = 2,ItemAwards2 = 3,ItemAwards3 = 0,ItemNumeber1 = 6,ItemNumeber2 = 350,ItemNumeber3 = 0,},
	{StarBox = 5,Star=15,ItemAwards1 = 1,ItemAwards2 = 4,ItemAwards3 = 0,ItemNumeber1 = 6,ItemNumeber2 = 5000,ItemNumeber3 = 0,},
	{StarBox = 6,Star=30,ItemAwards1 = 4,ItemAwards2 = 3,ItemAwards3 = 0,ItemNumeber1 = 8000,ItemNumeber2 = 1000,ItemNumeber3 = 0,},
}


function getStarBoxID(id) --宝箱ID
	starbox = starAwards[id].StarBox
	return starbox;
end

function getStarNumber(id) --可激活的星数
	star = starAwards[id].Star
	return star;
end

function getItemType(id,itemRewardType) --掉落物品类型(itemRewardType ItemAwards1,ItemAwards2,ItemAwards3)
	local rewardType = 0	
	
	if itemRewardType == 0 then 
		rewardType = starAwards[id].ItemAwards1
	elseif 	itemRewardType == 1 then 
		rewardType = starAwards[id].ItemAwards2
	else 
		rewardType = starAwards[id].ItemAwards3	
	end		
	
	if rewardType == 0 then
		return 0;
	end	
	
	resid = item[rewardType].itemType
	return resid;
end

function getItemNumber(id,itemRewardType) --掉落物品数量(itemRewardType ItemNumeber1,ItemNumeber2,ItemNumeber3)
	local number = 0	
	
	if itemRewardType == 0 then 
		number = starAwards[id].ItemNumeber1
	elseif 	itemRewardType == 1 then 
		number = starAwards[id].ItemNumeber2
	else 
		number = starAwards[id].ItemNumeber3	
	end				
	return number;
end
