
----popPricing < 0 时，不弹推送

---UIType 世界地图界面弹出推送数据 
-- ID世界地图上对应的关卡号
-- popPricing<参照 PricingItem.lua文件 填写计费点ID>
-- currentGateTag <0未开启 1 激活 2已开启>
local WorldMapGamePushData = {
{ID=101,	popPricing = -1,	currentGateTag = 1},
{ID=111,	popPricing = -1,	currentGateTag = 1},
{ID=121,	popPricing = -1,	currentGateTag = 1},
{ID=131,	popPricing = 1,		currentGateTag = 1},	
{ID=141,	popPricing = -1,	currentGateTag = 1},
{ID=151,	popPricing = -1,	currentGateTag = 1},
{ID=161,	popPricing = -1,	currentGateTag = 1},
{ID=171,	popPricing = -1,	currentGateTag = 1},
{ID=181,	popPricing = 10,	currentGateTag = 1},
{ID=191,	popPricing = -1,	currentGateTag = 1},
{ID=201,	popPricing = 11,	currentGateTag = 1},
{ID=211,	popPricing = 10,	currentGateTag = 1},
{ID=221,	popPricing = -1,	currentGateTag = 1},
{ID=231	,	popPricing = -1,	currentGateTag = 1},	
{ID=241,	popPricing = -1,	currentGateTag = 1},
{ID=251,	popPricing = -1,	currentGateTag = 1},
{ID=261,	popPricing = -1,	currentGateTag = 1},
{ID=271,	popPricing = -1,	currentGateTag = 1},
{ID=281,	popPricing = -1,	currentGateTag = 1},
{ID=291,	popPricing = -1,	currentGateTag = 1},
{ID=301,	popPricing = -1,	currentGateTag = 1},
{ID=311,	popPricing = -1,	currentGateTag = 1},
{ID=321,	popPricing = -1,	currentGateTag = 1},
{ID=331,	popPricing = -1,	currentGateTag = 1},	
{ID=341,	popPricing = -1,	currentGateTag = 1},
{ID=351,	popPricing = -1,	currentGateTag = 1},
{ID=361,	popPricing = -1,	currentGateTag = 1},
{ID=371,	popPricing = -1,	currentGateTag = 1},
{ID=381,	popPricing = -1,	currentGateTag = 1},
{ID=391,	popPricing = -1,	currentGateTag = 1},	
}

function getWorldMapCurrentGate(id) --当前触发的关卡
	return WorldMapGamePushData[id].ID;
end

function getWorldMapPopPricingType(id) --大地图弹出计费点ID
	local pricing = WorldMapGamePushData[id].popPricing
	return pricing;
end

function getWorldMapCurrentGateTag(id) --大地图上当前关卡状态
	local tag = WorldMapGamePushData[id].currentGateTag	
	return tag;
end

----popPricing < 0 时，不弹推送
---UIType 主城界面弹出推送数据 
-- ID游戏对应的关卡号
-- popPricing<参照 PricingItem.lua文件 填写计费点ID>
-- currentGateTag <0未开启 1 激活 2已开启>
local HomeGamePushData = {
{ID=101,	popPricing = -1,	currentGateTag = 1},
{ID=111,	popPricing = -1,	currentGateTag = 1},
{ID=121,	popPricing = -1,	currentGateTag = 1},
{ID=131,	popPricing = 1,		currentGateTag = 1},	
{ID=141,	popPricing = -1,	currentGateTag = 1},
{ID=151,	popPricing = -1,	currentGateTag = 1},
{ID=161,	popPricing = -1,	currentGateTag = 1},
{ID=171,	popPricing = -1,	currentGateTag = 1},
{ID=181,	popPricing = 10,	currentGateTag = 1},
{ID=191,	popPricing = -1,	currentGateTag = 1},
{ID=201,	popPricing = 11,	currentGateTag = 1},
{ID=211,	popPricing = 10,	currentGateTag = 1},
{ID=221,	popPricing = -1,	currentGateTag = 1},
{ID=231,	popPricing = -1,	currentGateTag = 1},	
{ID=241,	popPricing = -1,	currentGateTag = 1},
{ID=251,	popPricing = -1,	currentGateTag = 1},
{ID=261,	popPricing = -1,	currentGateTag = 1},
{ID=271,	popPricing = -1,	currentGateTag = 1},
{ID=281,	popPricing = -1,	currentGateTag = 1},
{ID=291,	popPricing = -1,	currentGateTag = 1},
{ID=301,	popPricing = -1,	currentGateTag = 1},
{ID=311,	popPricing = -1,	currentGateTag = 1},
{ID=321,	popPricing = -1,	currentGateTag = 1},
{ID=331,	popPricing = -1,	currentGateTag = 1},	
{ID=341,	popPricing = -1,	currentGateTag = 1},
{ID=351,	popPricing = -1,	currentGateTag = 1},
{ID=361,	popPricing = -1,	currentGateTag = 1},
{ID=371,	popPricing = -1,	currentGateTag = 1},
{ID=381,	popPricing = -1,	currentGateTag = 1},
{ID=391,	popPricing = -1,	currentGateTag = 1},----普通战斗


{ID=711,	popPricing = -1,	currentGateTag = 1},----副本
{ID=712,	popPricing = -1,	currentGateTag = 1},
{ID=721,	popPricing = 7,		currentGateTag = 1},
{ID=722,	popPricing = -1,	currentGateTag = 1},	
	

{ID=901,	popPricing = -1,	currentGateTag = 1},----千层塔
{ID=902,	popPricing = -1,	currentGateTag = 1},
{ID=903,	popPricing = -1,	currentGateTag = 1},
{ID=904,	popPricing = -1,	currentGateTag = 1},
{ID=905,	popPricing = -1,	currentGateTag = 1},
{ID=906,	popPricing = -1,	currentGateTag = 1},
{ID=907,	popPricing = -1,	currentGateTag = 1},
{ID=908,	popPricing = -1,	currentGateTag = 1},
{ID=909,	popPricing = -1,	currentGateTag = 1},
{ID=910,	popPricing = -1,	currentGateTag = 1},
{ID=911,	popPricing = -1,	currentGateTag = 1},
{ID=912,	popPricing = -1,	currentGateTag = 1},
{ID=913,	popPricing = -1,	currentGateTag = 1},
{ID=914,	popPricing = -1,	currentGateTag = 1},
{ID=915,	popPricing = -1,	currentGateTag = 1},
{ID=916,	popPricing = -1,	currentGateTag = 1},
{ID=917,	popPricing = -1,	currentGateTag = 1},
{ID=918,	popPricing = -1,	currentGateTag = 1},
{ID=919,	popPricing = -1,	currentGateTag = 1},
{ID=920,	popPricing = -1,	currentGateTag = 1},
{ID=921,	popPricing = -1,	currentGateTag = 1},
{ID=922,	popPricing = -1,	currentGateTag = 1},
{ID=923,	popPricing = -1,	currentGateTag = 1},
{ID=924,	popPricing = -1,	currentGateTag = 1},
{ID=925,	popPricing = -1,	currentGateTag = 1},
{ID=926,	popPricing = -1,	currentGateTag = 1},
{ID=927,	popPricing = -1,	currentGateTag = 1},
{ID=928,	popPricing = -1,	currentGateTag = 1},
{ID=929,	popPricing = -1,	currentGateTag = 1},
{ID=930,	popPricing = -1,	currentGateTag = 1},
{ID=931,	popPricing = -1,	currentGateTag = 1},
{ID=932,	popPricing = -1,	currentGateTag = 1},
{ID=933,	popPricing = -1,	currentGateTag = 1},
{ID=934,	popPricing = -1,	currentGateTag = 1},
{ID=935,	popPricing = -1,	currentGateTag = 1},
{ID=936,	popPricing = -1,	currentGateTag = 1},
{ID=937,	popPricing = -1,	currentGateTag = 1},
{ID=938,	popPricing = -1,	currentGateTag = 1},
{ID=939,	popPricing = -1,	currentGateTag = 1},
{ID=940,	popPricing = -1,	currentGateTag = 1},
{ID=941,	popPricing = -1,	currentGateTag = 1},
{ID=942,	popPricing = -1,	currentGateTag = 1},
{ID=943,	popPricing = -1,	currentGateTag = 1},
{ID=944,	popPricing = -1,	currentGateTag = 1},
{ID=945,	popPricing = -1,	currentGateTag = 1},
{ID=946,	popPricing = -1,	currentGateTag = 1},
{ID=947,	popPricing = -1,	currentGateTag = 1},
{ID=948,	popPricing = -1,	currentGateTag = 1},
{ID=949,	popPricing = -1,	currentGateTag = 1},
{ID=950,	popPricing = -1,	currentGateTag = 1},

}

function getHomeCurrentGate(id) --当前触发的关卡
	return HomeGamePushData[id].ID;
end

function getHomePopPricingType(id) --主城弹出计费点ID
	local pricing = HomeGamePushData[id].popPricing
	return pricing;
end

function getHomeCurrentGateTag(id) --主城当前关卡状态
	local tag = HomeGamePushData[id].currentGateTag	
	return tag;
end

----popPricing < 0 时，不弹推送
---UIType 千层塔弹出推送数据 
-- ID千层塔对应的关卡号
-- popPricing<参照 PricingItem.lua文件 填写计费点ID>
-- currentGateTag <0未开启 1 激活 2已开启>
local HuperziaGamePushData = {
{ID=901,	popPricing = -1,	currentGateTag = 1},----千层塔
{ID=902,	popPricing = 10,	currentGateTag = 1},
{ID=903,	popPricing = -1,	currentGateTag = 1},
{ID=904,	popPricing = 12,		currentGateTag = 1},
{ID=905,	popPricing = -1,	currentGateTag = 1},
{ID=906,	popPricing = 11,	currentGateTag = 1},
{ID=907,	popPricing = -1,	currentGateTag = 1},
{ID=908,	popPricing = -1,	currentGateTag = 1},
{ID=909,	popPricing = -1,	currentGateTag = 1},
{ID=910,	popPricing = -1,	currentGateTag = 1},
{ID=911,	popPricing = -1,	currentGateTag = 1},
{ID=912,	popPricing = -1,	currentGateTag = 1},
{ID=913,	popPricing = -1,	currentGateTag = 1},
{ID=914,	popPricing = -1,	currentGateTag = 1},
{ID=915,	popPricing = -1,	currentGateTag = 1},
{ID=916,	popPricing = -1,	currentGateTag = 1},
{ID=917,	popPricing = -1,	currentGateTag = 1},
{ID=918,	popPricing = -1,	currentGateTag = 1},
{ID=919,	popPricing = -1,	currentGateTag = 1},
{ID=920,	popPricing = -1,	currentGateTag = 1},
{ID=921,	popPricing = -1,	currentGateTag = 1},
{ID=922,	popPricing = -1,	currentGateTag = 1},
{ID=923,	popPricing = -1,	currentGateTag = 1},
{ID=924,	popPricing = -1,	currentGateTag = 1},
{ID=925,	popPricing = -1,	currentGateTag = 1},
{ID=926,	popPricing = -1,	currentGateTag = 1},
{ID=927,	popPricing = -1,	currentGateTag = 1},
{ID=928,	popPricing = -1,	currentGateTag = 1},
{ID=929,	popPricing = -1,	currentGateTag = 1},
{ID=930,	popPricing = -1,	currentGateTag = 1},
{ID=931,	popPricing = -1,	currentGateTag = 1},
{ID=932,	popPricing = -1,	currentGateTag = 1},
{ID=933,	popPricing = -1,	currentGateTag = 1},
{ID=934,	popPricing = -1,	currentGateTag = 1},
{ID=935,	popPricing = -1,	currentGateTag = 1},
{ID=936,	popPricing = -1,	currentGateTag = 1},
{ID=937,	popPricing = -1,	currentGateTag = 1},
{ID=938,	popPricing = -1,	currentGateTag = 1},
{ID=939,	popPricing = -1,	currentGateTag = 1},
{ID=940,	popPricing = -1,	currentGateTag = 1},
{ID=941,	popPricing = -1,	currentGateTag = 1},
{ID=942,	popPricing = -1,	currentGateTag = 1},
{ID=943,	popPricing = -1,	currentGateTag = 1},
{ID=944,	popPricing = -1,	currentGateTag = 1},
{ID=945,	popPricing = -1,	currentGateTag = 1},
{ID=946,	popPricing = -1,	currentGateTag = 1},
{ID=947,	popPricing = -1,	currentGateTag = 1},
{ID=948,	popPricing = -1,	currentGateTag = 1},
{ID=949,	popPricing = -1,	currentGateTag = 1},
{ID=950,	popPricing = -1,	currentGateTag = 1},

}

function getHuperziaCurrentGate(id) --当前触发的关卡
	return HuperziaGamePushData[id].ID;
end

function getHuperziaPopPricingType(id) --千层塔弹出计费点ID
	local pricing = HuperziaGamePushData[id].popPricing
	return pricing;
end

function getHuperziaCurrentGateTag(id) --千层塔当前关卡状态
	local tag = HuperziaGamePushData[id].currentGateTag	
	return tag;
end