----
QTE = {
--慢--
{ID=1,		SectionNum=1,		Section1=20,	Section2=0,		Time1=4000,		Time2=3000,		SubHP=10,		AddHP=10},
{ID=2,		SectionNum=1,		Section1=20,	Section2=0,		Time1=10000,	Time2=10000,	SubHP=10,		AddHP=10},
}


function getEnemyID(id)	
	currentEnemyID = EnemyProperty[id].ID
	return currentEnemyID;
end

function getSectionNum(id) -- 获取QTE段数	
   sectionNum = QTE[id].SectionNum
   return sectionNum;
end 

function getSection(id,sectionType) -- 触发QTE 当前血量<百分比> |sectionType阶段 	
	local currentHP = 0
	if sectionType == 0 then
		currentHP = QTE[id].Section1
	elseif sectionType == 1 then
		currentHP = QTE[id].Section2
	end
  
   return currentHP;
end 

function getQTETime(id,sectionType) -- QTE等待时间	
	local currentTime = 0
	if sectionType == 0 then
		currentTime = QTE[id].Time1
	elseif sectionType == 1 then
		currentTime = QTE[id].Time2
	end
  
   return currentTime;
end 

function getSubHP(id) -- QTE成功后减血<百分比>	
   subHP = QTE[id].SubHP
   return subHP;
end 

function getAddHP(id) -- QTE失败后加血<百分比>	
   addHP = QTE[id].AddHP
   return addHP;
end 