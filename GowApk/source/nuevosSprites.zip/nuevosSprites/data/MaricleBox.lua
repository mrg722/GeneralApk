MaricleBoxData = {
{Type = 1,  Name = "伤害X1.3",		   			OneTimes = true, BuffState = 6,showProplity = 8.5,InforMation = "本次战斗攻击伤害提升1.3倍。",},
{Type = 2,  Name = "伤害X1.8", 		    		OneTimes = true, BuffState = 6,showProplity = 3.0,InforMation = "本次战斗攻击伤害提升1.8倍。",},
{Type = 3,  Name = "获得药品", 		    		OneTimes = false,BuffState = -1,showProplity = 8.5,InforMation = "获得生命药、能量药各3个。",},
{Type = 4,  Name = "收益加成1.8倍", 		    OneTimes = true, BuffState = 4,showProplity = 3.0,InforMation = "本次战斗金币、红魂、经验值的获得是普通情况下的1.8倍。",},
{Type = 5,  Name = "收益加成1.3倍", 		    OneTimes = true, BuffState = 4,showProplity = 8.0,InforMation = "本次战斗金币、红魂、经验值的获得是普通情况下的1.3倍。",},
{Type = 6,  Name = "暴击提升150", 				OneTimes = true, BuffState = 1,showProplity = 3.0,InforMation = "本次战斗的暴击率提升15%。",},
{Type = 7, Name = "暴击提升80", 				OneTimes = true, BuffState = 1,showProplity = 8.5,InforMation = "本次战斗的暴击率提升8%。",},
{Type = 8, Name = "移动速度提升50%", 			OneTimes = true, BuffState = 5,showProplity = 3.0,InforMation = "本次战斗移动速度提升50%。",},
{Type = 9, Name = "移动速度提升30%", 			OneTimes = true, BuffState = 5,showProplity = 8.5,InforMation = "本次战斗移动速度提升30%。",},
{Type = 10, Name = "50%伤害减免", 				OneTimes = true, BuffState = 2,showProplity = 3.0,InforMation = "本次战斗获得50%伤害减免。",},
{Type = 11, Name = "25%伤害减免", 				OneTimes = true, BuffState = 2,showProplity = 8.5,InforMation = "本次战斗获得25%伤害减免。",},
{Type = 12, Name = "血量+50%", 					OneTimes = true, BuffState = 3,showProplity = 3.0,InforMation = "本次战斗血量增加50%。",},
{Type = 13, Name = "血量+20%",					OneTimes = true, BuffState = 3,showProplity = 8.5,InforMation = "本次战斗血量增加20%。",},
{Type = 14, Name = "攻击提升30%", 				OneTimes = true, BuffState = 6,showProplity = 3.0,InforMation = "本次战斗攻击提升30%。",},
{Type = 15, Name = "攻击提升15%", 				OneTimes = true, BuffState = 6,showProplity = 8.5,InforMation = "本次战斗攻击提升15%。",},
{Type = 16, Name = "防御提升30%", 				OneTimes = true, BuffState = 2,showProplity = 3.0,InforMation = "本次战斗防御提升30%。",},
{Type = 17, Name = "防御提升15%", 				OneTimes = true, BuffState = 2,showProplity = 8.5,InforMation = "本次战斗防御提升15%。",},
}


function getMaricleBoxDataLength() --数组长度（物品个数）
	return table.getn(MaricleBoxData);
end

function getBoxID(id) ----神秘宝箱类型
	local boxType = MaricleBoxData[id].Type
	return boxType
end

function getBoxName(id) ----神秘宝箱名称
	local boxName = MaricleBoxData[id].Name
	return boxName
end

function getBoxOneTimes(id) ----神秘宝箱是否一次性(true 是一次性 , false 可重复)
	local onetimes = MaricleBoxData[id].OneTimes
	return onetimes
end

function getBoxShowProplity(id) ----神秘宝箱该功能出现概率
	local proplity = MaricleBoxData[id].showProplity
	return proplity
end

function getBoxInforMation(id) ----神秘宝箱该功能描述
	local info = MaricleBoxData[id].InforMation
	return info
end

function getMaricleBoxBuffState(id)---神秘宝箱Buff对应的乐堂状态
	local boxBuffState = MaricleBoxData[id].BuffState
	return boxBuffState
end
-----------------战前准备BUFF状态<对应乐堂动画状态>
BattleReadyData = {
{Type = 1,  Name = "伤害加深",		   			BuffState = 6,},
{Type = 2,  Name = "获得药品", 		    		BuffState = -1,},
{Type = 3,  Name = "收益加成", 		    		BuffState = 4,},
{Type = 4,  Name = "试用武器1（物攻）", 	 	BuffState = -1,},
{Type = 5,  Name = "试用武器2（魔攻）", 		BuffState = -1,},
{Type = 6,  Name = "试用武器3（双修）", 		BuffState = -1,},
{Type = 7, 	Name = "暴击提升", 					BuffState = 1,},
{Type = 8, 	Name = "神秘宝箱", 					BuffState = -1,},
{Type = 9, 	Name = "神速", 						BuffState = 5,},
{Type = 10, Name = "肉盾", 						BuffState = 2,},
{Type = 11, Name = "获得武器1", 				BuffState = -1,},
{Type = 12, Name = "获得武器2", 				BuffState = -1,},
{Type = 13, Name = "获得武器3",					BuffState = -1,},
{Type = 14, Name = "战意", 						BuffState = 0,},
}

function getBattleReadyBuffState(id)---战前准备Buff对应的乐堂状态
	local brBuffState = BattleReadyData[id].BuffState
	return brBuffState
end
