function getRedSoulsWord(souls)	
	str = "恭喜获得：红魂X" .. souls
	return str;
end
function getGlodWold(money)
	str = "恭喜获得：金币X" .. money
	return str;
end
function getHPWold(battle)
	str = "恭喜获得：生命药X" .. battle
	return str
end
function getMPWold(battle)
	str = "恭喜获得：能量药X" .. battle
	return str
end
function getMP(mp)
	str = "恭喜获得：能量" .. mp
	return str
end
function getExp(exps)
	str = "恭喜获得：经验X" .. exps
	return str
end