function StartGameGate() ---开始游戏关卡	
	return 100;
end

function OpenDebugMode() ----开启Debug调试信息 <返回 true 开启, false 关闭,默认关闭>	
	return false
end

function SetHeroType() ---设置主角初始武器 0混沌刃 1拳套 2电光链 3钩爪	
	return 0;
end

function getHeroFronTrumbleDiffrenceTime()---主角翻滚按键时间间隔
	local diffrenceTime = 1.0
	return diffrenceTime;
end

function getHeroFrontTrumbleCDTime() ----主角翻滚冷却时间
	local cdTime = 0.5
	return cdTime;
end

function getHeroBehitWaitTime() ----主角被打后等待时间   清除霸体
local waittime = 3.0
	return waittime;
end

function getPressSkillButtonTimes()--主角没蓝按技能次数 <触发买药计费点>
	local pressSkillTimes = 5
	return pressSkillTimes;
end

function makeMoreMoneyTimes() ---赚金币进入次数	
	return 2;
end

function makeMoreExpTimes() ---赢经验进入次数	
	return 2;
end

function redSoulsTimes() ---取红魂次数	
	return 2;
end

function HeroWeaponMaxLevel(weaponType)-----武器最大等级
	if weaponType == 0 then 
		return 30;
	elseif weaponType == 1 then 
		return 30;
	elseif weaponType == 2 then 
		return 30;
	elseif weaponType == 3 then 
		return 40;
	end
end

function HeroWeaponMinLevel(weaponType)-----武器最小等级
	if weaponType == 0 then 
		return 1;
	elseif weaponType == 1 then 
		return 1;
	elseif weaponType == 2 then 
		return 1;
	elseif weaponType == 3 then 
		return 11;
	end
end

function currentGateName(gate) ---当前关卡号
	str = "当前关卡：" .. gate
	return str;
end

function SnowInGate(gate) ---雪山内景关卡
	if gate == 222 then
		return true;
	elseif gate == 232 then
		return true;
	elseif gate == 242 then
		return true;
	elseif gate == 243 then
		return true;
	elseif gate == 282 then
		return true;
	elseif gate == 314 then
		return true;
	elseif gate == 316 then
		return true;
	elseif gate == 371 then
		return true;
	elseif gate == 372 then
		return true;
	elseif gate == 904 then
		return true;
	elseif gate == 910 then
		return true;
	elseif gate == 918 then
		return true;
	elseif gate == 922 then
		return true;
	elseif gate == 926 then
		return true;
	elseif gate == 933 then
		return true;
	elseif gate == 940 then
		return true;
	elseif gate == 944 then
		return true;
	elseif gate == 949 then
		return true;
	end
	return false;	
end
function SnowOutGate(gate) ---雪山外景关卡
	if gate == 201 then
		return true;
	elseif gate == 202 then
		return true;
	elseif gate == 211 then
		return true;
	elseif gate == 212 then
		return true;
	elseif gate == 221 then
		return true;
	elseif gate == 231 then
		return true;
	elseif gate == 241 then
		return true;
	elseif gate == 281 then
		return true;
	elseif gate == 315 then
		return true;
	elseif gate == 317 then
		return true;
	elseif gate == 318 then
		return true;
	elseif gate == 331 then
		return true;
	elseif gate == 351 then
		return true;
	elseif gate == 352 then
		return true;
	elseif gate == 391 then
		return true;
	elseif gate == 392 then
		return true;
	elseif gate == 393 then
		return true;
	elseif gate == 721 then
		return true;
	elseif gate == 722 then
		return true;
	elseif gate == 905 then
		return true;
	elseif gate == 909 then
		return true;
	elseif gate == 916 then
		return true;
	elseif gate == 920 then
		return true;
	elseif gate == 924 then
		return true;
	elseif gate == 929 then
		return true;
	elseif gate == 932 then
		return true;
	elseif gate == 937 then
		return true;
	elseif gate == 941 then
		return true;
	elseif gate == 948 then
		return true;
	end
	return false;	
end

function BoatGate(gate)---战船外部下雨关卡
	if gate == 100 then
		return true;
	elseif gate == 101 then
		return true;
	elseif gate == 121 then
		return true;
	elseif gate == 122 then
		return true;
	elseif gate == 131 then
		return true;
	elseif gate == 133 then
		return true;
	elseif gate == 181 then
		return true;
	elseif gate == 251 then
		return true;
	elseif gate == 271 then
		return true;
	elseif gate == 273 then
		return true;
	elseif gate == 291 then
		return true;
	elseif gate == 293 then
		return true;
	elseif gate == 361 then
		return true;
	elseif gate == 711 then
		return true;
	elseif gate == 712 then
		return true;
	elseif gate == 901 then
		return true;
	elseif gate == 908 then
		return true;
	elseif gate == 912 then
		return true;
	elseif gate == 913 then
		return true;
	elseif gate == 917 then
		return true;
	elseif gate == 927 then
		return true;
	elseif gate == 936 then
		return true;
	elseif gate == 939 then
		return true;
	elseif gate == 945 then
		return true;
	elseif gate == 950 then
		return true;
	end		
	return false;	
end

function BoatInGate(gate)---战船内关卡
	if gate == 111 then
		return true;
	elseif gate == 112 then
		return true;
	elseif gate == 132 then
		return true;
	elseif gate == 191 then
		return true;
	elseif gate == 192 then
		return true;
	elseif gate == 193 then
		return true;
	elseif gate == 252 then
		return true;
	elseif gate == 261 then
		return true;
	elseif gate == 272 then
		return true;
	elseif gate == 362 then
		return true;
	elseif gate == 292 then
		return true;
	elseif gate == 903 then
		return true;
	elseif gate == 914 then
		return true;
	elseif gate == 925 then
		return true;
	elseif gate == 931 then
		return true;
	elseif gate == 934 then
		return true;
	elseif gate == 942 then
		return true;
	elseif gate == 946 then
		return true;
	end
	return false;	
end

function BoatGateSmallBackRound(gate)---战船关卡地图小背景
	if gate == 100 then
		return true;
	elseif gate == 121 then
		return true;
	elseif gate == 122 then
		return true;
	elseif gate == 133 then
		return true;
	elseif gate == 193 then
		return true;
	elseif gate == 271 then
		return true;
	elseif gate == 273 then
		return true;
	elseif gate == 291 then
		return true;
	elseif gate == 293 then
		return true;
	elseif gate == 711 then
		return true;
	elseif gate == 712 then
		return true;
	elseif gate == 901 then
		return true;
	elseif gate == 908 then
		return true;
	elseif gate == 912 then
		return true;
	elseif gate == 913 then
		return true;
	elseif gate == 936 then
		return true;
	elseif gate == 950 then
		return true;
	end		
	return false;	
end

function FireOutGateBackRound(gate)---火山外关卡背景
	if gate == 141 then
		return true;
	elseif gate == 142 then
		return true;
	elseif gate == 151 then
		return true;
	elseif gate == 161 then
		return true;
	elseif gate == 162 then
		return true;
	elseif gate == 163 then
		return true;
	elseif gate == 171 then
		return true;
	elseif gate == 172 then
		return true;
	elseif gate == 301 then
		return true;
	elseif gate == 302 then
		return true;
	elseif gate == 311 then
		return true;
	elseif gate == 312 then
		return true;
	elseif gate == 321 then
		return true;
	elseif gate == 322 then
		return true;
	elseif gate == 341 then
		return true;
	elseif gate == 342 then
		return true;
	elseif gate == 343 then
		return true;
	elseif gate == 381 then
		return true;
	elseif gate == 382 then
		return true;		
	elseif gate == 991 then
		return true;
	elseif gate == 902 then
		return true;
	elseif gate == 906 then
		return true;
	elseif gate == 907 then
		return true;
	elseif gate == 911 then
		return true;
	elseif gate == 915 then
		return true;
	elseif gate == 919 then
		return true;
	elseif gate == 921 then
		return true;
	elseif gate == 923 then
		return true;
	elseif gate == 928 then
		return true;
	elseif gate == 930 then
		return true;
	elseif gate == 935 then
		return true;
	elseif gate == 938 then
		return true;
	elseif gate == 943 then
		return true;
	elseif gate == 947 then
		return true;
	end		
	return false;	
end

function teachQTETouchGate(gate)---QTE教学滑动 触发关卡号
	if gate == 110 then
		return true;
	 end
	 return false;	
end

function getGameCopyGate(gate)----获得游戏副本关卡号
	if gate == 711 then---赚金币关卡
		return true;
	elseif gate == 712 then---赚金币关卡
		return true;
	elseif gate == 721 then---取红魂关卡
		return true;
	elseif gate == 722 then---取红魂关卡
		return true;	
	end
	return false;	
end

function getHeroDieReturnGateID(gate)---主角死亡后需切换的关卡号
	local currentGate = 0; 
	if gate < 700 then
		currentGate = (gate / 100 * 100) + (gate % 100 / 10 * 10) + 1
	else
		currentGate = gate
	end	
	return currentGate;
end

function huperziaScoreName(score,taskType) ---千层塔任务积分<score 积分,taskType 任务类型>
	str = "任务完成积分" .. taskType .. "：" .. score
	return str;
end

function huperziaBasicScoreName(score) ---千层塔基础积分
	str = "基础积分：" .. score
	return str;
end

function huperziaFightScoreName(score) ---千层塔战斗力奖励积分
	str = "战斗力奖励积分：" .. score
	return str;
end

function huperziaVIPScoreName(score) ---千层塔VIP积分
	str = "VIP奖励积分：" .. score
	return str;
end

function huperziaRandomScoreName(score) ---千层塔随机积分
	str = "随机奖励积分：" .. score
	return str;
end

function passFirstGateReward(rewardType)----初次通关第一关奖励<0,金币 1,红魂>
	if rewardType == 0 then ---奖励金币
		money = 300
		return money;
	elseif rewardType == 1 then ---奖励红魂
		souls = 1500
		return souls
	end
end
