EnemysoudEffectDate={
--普通小兵--		
{ID=1,Type="骷髅兵",			behitSound = "sound67",  dieSound = "",},	
{ID=2,Type="骷髅盾兵",			behitSound = "sound67",  dieSound = "",},	
{ID=3,Type="钻地怪",    		behitSound = "sound67",  dieSound = "",},	
{ID=4,Type="象怪",      		behitSound = "sound68",  dieSound = "",},	
{ID=5,Type="半人马",    		behitSound = "sound39",  dieSound = "",},	
{ID=6,Type="链球怪1",    		behitSound = "sound68",  dieSound = "",},	
{ID=7,Type="链球怪2",    		behitSound = "sound68",  dieSound = "",},	
{ID=8,Type="美杜莎1",    		behitSound = "sound31",  dieSound = "",},	
--精英A，有QTE，绿名，5倍初始血量，5倍成长血量，全属性小提升
{ID=9,Type="精英骷髅兵",  		behitSound = "sound67",  dieSound = "sound66",},	
{ID=10,Type="精英骷髅盾兵",		behitSound = "sound67",  dieSound = "sound66",},	
{ID=11,Type="精英钻地怪",    	behitSound = "sound67",  dieSound = "sound66",},	
{ID=12,Type="精英象怪",      	behitSound = "sound68",  dieSound = "sound69",},	
{ID=13,Type="精英半人马",    	behitSound = "sound39",  dieSound = "sound40",},	
{ID=14,Type="精英链球怪",   	behitSound = "sound68",  dieSound = "sound69",},	 
{ID=15,Type="精英蛇发女妖",    	behitSound = "sound31",  dieSound = "sound32",},	 
--变异A，红名，6倍初始血量，6倍成长血量，全属性中提升，特定属性大提升	
{ID=16,Type="骷髅兵",  			behitSound = "sound67",  dieSound = "sound66",},	
{ID=17,Type="骷髅盾兵",			behitSound = "sound67",  dieSound = "sound66",},	
{ID=18,Type="钻地怪",    		behitSound = "sound67",  dieSound = "sound66",},	
{ID=19,Type="象怪",      		behitSound = "sound68",  dieSound = "sound69",},	
{ID=20,Type="半人马",    		behitSound = "sound39",  dieSound = "sound40",},	
{ID=21,Type="链球怪",    		behitSound = "sound68",  dieSound = "sound69",},	
{ID=22,Type="蛇发女妖",     	behitSound = "sound31",  dieSound = "sound32",},	
--世界BOSS，10倍血量，全属性中提升	
{ID=23,Type="半人马",    		behitSound = "sound39",  dieSound = "sound40",},	
{ID=24,Type="链球怪",    		behitSound = "sound68",  dieSound = "sound69",},	
{ID=25,Type="蛇发女妖",     	behitSound = "sound31",  dieSound = "sound32",},	
--前期专用怪物，普通小兵，拥有QTE
{ID=26,Type="半人马",    		behitSound = "sound39",  dieSound = "sound40",},	
{ID=27,Type="链球怪1",    		behitSound = "sound68",  dieSound = "sound69",},	
{ID=28,Type="链球怪2",    		behitSound = "sound68",  dieSound = "sound69",},	
{ID=29,Type="美杜莎1",    		behitSound = "sound31",  dieSound = "sound32",},	
--真·世界BOSS，15倍血量（骷髅兵计算），全属性大提升	
{ID=30,Type="触手怪",    		behitSound = "sound52",  dieSound = "sound51",},	
{ID=31,Type="泰坦巨人",    		behitSound = "sound56",  dieSound = "sound55",},	
{ID=32,Type="波塞冬",     		behitSound = "sound59",  dieSound = "sound60",},	
--精英B，无QTE，绿名，5倍初始血量，5倍成长血量，全属性小提升
{ID=33,Type="精英半人马",    	behitSound = "sound39",  dieSound = "sound40",},	
{ID=34,Type="精英链球怪",   	behitSound = "sound68",  dieSound = "sound69",},	 
{ID=35,Type="精英蛇发女妖",    	behitSound = "sound31",  dieSound = "sound32",},	 
--NPC,36护送女，37雅典娜，38宙斯
{ID=36,Type="NPC",    			behitSound = "sound42",  dieSound = "sound43",},	 
{ID=37,Type="NPC",    			behitSound = "sound47",  dieSound = "sound47",},	 
{ID=38,Type="NPC",    			behitSound = "sound47",  dieSound = "sound47",},	 
}


--获得敌人被打音效
function getEnemyBehitSoudEffect(ID)
	filename = EnemysoudEffectDate[ID].behitSound
	if filename == "" then
		return "";
	end
	fileNamePath ="sound/"..filename..".ogg"	
	return fileNamePath;
end

--获得敌人死亡音效
function getEnemyDieSoudEffect(ID)
	filename = EnemysoudEffectDate[ID].dieSound
	if filename == "" then
		return "";
	end
	fileNamePath ="sound/"..filename..".ogg"
	return fileNamePath;
end

function GateBackRoundMusic(GateType)---战船外部下雨关卡背景音乐
	local musicFile = ""
	if GateType == 0 then--船
		musicFile = "sound/gate1music.ogg"	
	elseif GateType == 1 then--火山
		musicFile = "sound/gate2music.ogg"	
	end
	return musicFile;
end

---各个主界面背景音乐
function GameUIBackRoundMusic(UIType)
	local musicFile = ""
	if UIType == 12 then ---游戏主城
		musicFile = "sound/music_001.ogg"
	elseif 	UIType == 1 then ---游戏主菜单
		musicFile = "sound/menu.ogg"
	elseif 	UIType == 20 or UIType == 26 or UIType == 31 or UIType == 34 then --- 20技能界面 ，26千层塔 ，31武器界面 ，34游戏排行榜
		musicFile = "sound/music_001.ogg"
	elseif 	UIType == 16 then ---游戏胜利
		musicFile = "sound/music_002.ogg"
	elseif 	UIType == 17 then ---游戏失败
		musicFile = "sound/music_003.ogg"
	elseif 	UIType == 3 then ---游戏CG
		musicFile = "sound/gameCG.ogg"	
	end	
	return musicFile;
end


------------------------------<<---------------------------游戏音效--------------------------------->>----------------------------------------------
----填写须知:: 格式"sound/xxx.ogg",sound/文件夹名 , xxx.ogg音效文件名

soudEffectData = {
{soudType = 1,name = "打开窗口",		isLoop = 0,soundFormat = ".ogg",fileName = "sound1",},
{soudType = 2,name = "关闭窗口",		isLoop = 0,soundFormat = ".ogg",fileName = "sound2",},
{soudType = 3,name = "宙斯电光链音效",	isLoop = 1,soundFormat = ".ogg",fileName = "sound3",},
{soudType = 4,name = "哈迪斯钩爪音效",	isLoop = 1,soundFormat = ".ogg",fileName = "sound4",},
{soudType = 5,name = "尼米亚拳套音效",	isLoop = 1,soundFormat = ".ogg",fileName = "sound5",},
{soudType = 6,name = "药剂音",			isLoop = 0,soundFormat = ".ogg",fileName = "sound6",},
{soudType = 7,name = "金币音",			isLoop = 0,soundFormat = ".ogg",fileName = "sound7",},
{soudType = 8,name = "红魂音",			isLoop = 0,soundFormat = ".ogg",fileName = "sound38",},
{soudType = 9,name = "碎片音",			isLoop = 0,soundFormat = ".ogg",fileName = "sound9",},
{soudType = 10,name = "打开宝箱",		isLoop = 0,soundFormat = ".ogg",fileName = "sound10",},
{soudType = 11,name = "技能升级成功",	isLoop = 0,soundFormat = ".ogg",fileName = "sound11",},
{soudType = 12,name = "升级技能蓄力",	isLoop = 0,soundFormat = ".ogg",fileName = "sound12",},
{soudType = 13,name = "切换技能",		isLoop = 0,soundFormat = ".ogg",fileName = "sound13",},
{soudType = 14,name = "切换武器",		isLoop = 0,soundFormat = ".ogg",fileName = "sound14",},
{soudType = 15,name = "武器升星",		isLoop = 0,soundFormat = ".ogg",fileName = "sound15",},
{soudType = 16,name = "武器升级成功",	isLoop = 0,soundFormat = ".ogg",fileName = "sound16",},
{soudType = 17,name = "武器升级失败",	isLoop = 0,soundFormat = ".ogg",fileName = "sound17",},
{soudType = 18,name = "装备武器音",		isLoop = 0,soundFormat = ".ogg",fileName = "sound18",},
{soudType = 19,name = "解锁武器音",		isLoop = 0,soundFormat = ".ogg",fileName = "sound19",},
{soudType = 20,name = "角色升级",		isLoop = 0,soundFormat = ".ogg",fileName = "sound20",},
{soudType = 21,name = "购买",			isLoop = 0,soundFormat = ".ogg",fileName = "sound21",},
{soudType = 22,name = "出战",			isLoop = 0,soundFormat = ".ogg",fileName = "sound1",},
{soudType = 23,name = "新关卡开启",		isLoop = 0,soundFormat = ".ogg",fileName = "sound23",},
{soudType = 24,name = "确认提示出现",	isLoop = 0,soundFormat = ".ogg",fileName = "sound24",},
{soudType = 25,name = "关卡类型提示",	isLoop = 0,soundFormat = ".ogg",fileName = "sound25",},
{soudType = 26,name = "三二一读秒",		isLoop = 0,soundFormat = ".ogg",fileName = "sound27",},
{soudType = 27,name = "游戏暂停",		isLoop = 0,soundFormat = ".ogg",fileName = "sound29",},
{soudType = 28,name = "千层塔切换",		isLoop = 0,soundFormat = ".ogg",fileName = "sound30",},
{soudType = 29,name = "角色前窜(待换)",	isLoop = 0,soundFormat = ".ogg",fileName = "sound33",},
{soudType = 30,name = "角色死亡",		isLoop = 0,soundFormat = ".ogg",fileName = "sound34",},
{soudType = 31,name = "角色复活",		isLoop = 0,soundFormat = ".ogg",fileName = "sound35",},
{soudType = 32,name = "角色受伤",		isLoop = 0,soundFormat = ".ogg",fileName = "sound36",},
{soudType = 33,name = "教学提示",		isLoop = 0,soundFormat = ".ogg",fileName = "sound11",},
{soudType = 34,name = "机关提示",		isLoop = 0,soundFormat = ".ogg",fileName = "sound44",},
{soudType = 35,name = "传送门",			isLoop = 0,soundFormat = ".ogg",fileName = "sound45",},
{soudType = 36,name = "机关开门",		isLoop = 0,soundFormat = ".ogg",fileName = "sound46",},
{soudType = 37,name = "战斗胜利间接音",	isLoop = 0,soundFormat = ".ogg",fileName = "sound48",},
{soudType = 38,name = "第一次攻击",		isLoop = 0,soundFormat = ".ogg",fileName = "sound61",},
{soudType = 39,name = "第二次攻击",		isLoop = 0,soundFormat = ".ogg",fileName = "sound62",},
{soudType = 40,name = "第三次攻击",		isLoop = 0,soundFormat = ".ogg",fileName = "sound63",},
{soudType = 41,name = "第四次攻击",		isLoop = 0,soundFormat = ".ogg",fileName = "sound64",},
{soudType = 42,name = "第五次攻击",		isLoop = 0,soundFormat = ".ogg",fileName = "sound65",},
{soudType = 43,name = "关卡宝箱开启",	isLoop = 0,soundFormat = ".ogg",fileName = "sound26",},
{soudType = 44,name = "技能1正数第1帧",	isLoop = 0,soundFormat = ".ogg",fileName = "sound65",},--精灵号1,状态号1
{soudType = 45,name = "技能1倒数第15帧",isLoop = 0,soundFormat = ".ogg",fileName = "sound38",},--精灵号1,状态号2
{soudType = 46,name = "技能2倒数第2帧", isLoop = 0,soundFormat = ".ogg",fileName = "sound63",},--精灵号1,状态号3
{soudType = 47,name = "技能2倒数第2,4", isLoop = 0,soundFormat = ".ogg",fileName = "sound64",},--精灵号1,状态号4,技能2倒数第2,4,8,16,20,24,28帧
{soudType = 48,name = "技能2正数第1帧",	isLoop = 0,soundFormat = ".ogg",fileName = "sound65",},--精灵号1,状态号5
{soudType = 49,name = "技能2倒数第20帧",isLoop = 0,soundFormat = ".ogg",fileName = "sound38",},--精灵号1,状态号5
{soudType = 50,name = "技能3正数第1帧", isLoop = 0,soundFormat = ".ogg",fileName = "sound37",},--精灵号86,状态号1
{soudType = 51,name = "技能3倒数第22帧",isLoop = 0,soundFormat = ".ogg",fileName = "sound65",},--精灵号86,状态号1
{soudType = 52,name = "技能3倒数第8,30",isLoop = 0,soundFormat = ".ogg",fileName = "sound38",},--精灵号86,状态号1,技能3倒数第8,30,36,16,41,47,54帧
{soudType = 53,name = "前窜动作",		isLoop = 0,soundFormat = ".ogg",fileName = "sound70",},--前窜、垂直下滑起跳、插墙起跳、下滑绳子起跳
{soudType = 54,name = "蓄力准备跳",		isLoop = 0,soundFormat = ".ogg",fileName = "sound70",},--蓄力准备跳、爬上台、蓄力跳起、荡秋千
{soudType = 55,name = "拉机关",			isLoop = 0,soundFormat = ".ogg",fileName = "sound72",},--拉机关、奎托斯喊开门中
{soudType = 56,name = "拳套攻击第一下",	isLoop = 0,soundFormat = ".ogg",fileName = "sound73",},--拳套攻击第一下、拳套攻击第二下
{soudType = 57,name = "拳套攻击第三下",	isLoop = 0,soundFormat = ".ogg",fileName = "sound74",},--拳套攻击第三下、7-16倒数第1帧
{soudType = 58,name = "混沌之刃音效",	isLoop = 0,soundFormat = ".ogg",fileName = "sound75",},
}

---音效文件总数
function getSoundNumber()
	local length = table.getn(soudEffectData)
	return length
end

----音效文件类型<指什么地方用的>
function getSoundType(soundID)
	if soundID <= 0 then
		return -1;
	end
	local soundtype = soudEffectData[soundID].soudType
	return soundtype
end

----音效文件用处描述
function getSoundName(soundID)
	if soundID <= 0 then
		return "";
	end
	local soundName = soudEffectData[soundID].name
	return soundName
end

----音效文件格式
function getSoundFormatName(soundID)
	if soundID <= 0 then
		return "";
	end
	local soundformat = soudEffectData[soundID].soundFormat
	return soundformat
end

----音效是否循环(0不循环 1循环)
function getSoundFormatName(soundID)
	if soundID <= 0 then
		return false;
	end
	local loop = soudEffectData[soundID].isLoop	
	if loop == 1 then 
		return true;
	end
	return false
end

----音效文件名称
function getSoundFileName(soundID)
	if soundID <= 0 then
		return "";
	end
	local FileNames = soudEffectData[soundID].fileName
	local soundformat = soudEffectData[soundID].soundFormat
	soundFileName = "sound/"..FileNames..soundformat
	return soundFileName
end
