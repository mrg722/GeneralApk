--actionState(0--N,UI编辑器内状态号)
StoryDialog = {
{SDID = 1, SDName = "奎托斯",  SDText = "雅蠛蝶，好疼！呜呜~~~~",},

}

function DialogsNumber()	--剧情对话(ID数量)
	length = table.getn(StoryDialog)
	return length;
end

function DialogID(id)	--对话ID
	speakID = StoryDialog[id].SDID
	return speakID;
end

function DialogText(id) --对话内容
	speakContent = StoryDialog[id].SDText
	return speakContent;
end
