local item = {
	{itemType=1,Name="生命药",},
	{itemType=2,Name="能量药",},
	{itemType=3,Name="金币",},
	{itemType=4,Name="红魂",},
	{itemType=5,Name="经验",},
	{itemType=6,Name="拳套碎片1",},
	{itemType=7,Name="拳套碎片2",},
	{itemType=8,Name="拳套碎片3",},
	{itemType=9,Name="电光链碎片1",},
	{itemType=10,Name="电光链碎片2",},
	{itemType=11,Name="电光链碎片3",},
	{itemType=12,Name="电光链碎片4",},
	{itemType=13,Name="电光链碎片5",},
	{itemType=14,Name="电光链碎片6",},
}

--ItemAwards1 ItemAwards2 ItemAwards3 道具类型|  ItemNumeber1 ItemNumeber2 ItemNumeber2 道具数量
local HuperziaRewardData = {
{BoxID = 1,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 400,Number2 = 90,Number3 = 0,Number4 = 0,},
{BoxID = 2,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 110,Number2 = 25,Number3 = 0,Number4 = 0,},
{BoxID = 3,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 150,Number2 = 35,Number3 = 0,Number4 = 0,},
{BoxID = 4,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 190,Number2 = 45,Number3 = 0,Number4 = 0,},
{BoxID = 5,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 230,Number2 = 55,Number3 = 0,Number4 = 0,},
{BoxID = 6,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 270,Number2 = 65,Number3 = 0,Number4 = 0,},
{BoxID = 7,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 310,Number2 = 75,Number3 = 0,Number4 = 0,},
{BoxID = 8,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 350,Number2 = 85,Number3 = 0,Number4 = 0,},
{BoxID = 9,Item1 =  4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 390,Number2 = 95,Number3 = 0,Number4 = 0,},
{BoxID = 10,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 430,Number2 = 105,Number3 = 0,Number4 = 0,},
{BoxID = 11,Item1 = 4,Item2 = 3,Item3 = 12,Item4 = 0,Number1 = 470,Number2 = 115,Number3 = 1,Number4 = 0,},
{BoxID = 12,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 510,Number2 = 125,Number3 = 0,Number4 = 0,},
{BoxID = 13,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 550,Number2 = 135,Number3 = 0,Number4 = 0,},
{BoxID = 14,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 590,Number2 = 145,Number3 = 0,Number4 = 0,},
{BoxID = 15,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 630,Number2 = 155,Number3 = 0,Number4 = 0,},
{BoxID = 16,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 670,Number2 = 165,Number3 = 0,Number4 = 0,},
{BoxID = 17,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 710,Number2 = 175,Number3 = 0,Number4 = 0,},
{BoxID = 18,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 750,Number2 = 185,Number3 = 0,Number4 = 0,},
{BoxID = 19,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 790,Number2 = 195,Number3 = 0,Number4 = 0,},
{BoxID = 20,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 830,Number2 = 205,Number3 = 0,Number4 = 0,},
{BoxID = 21,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 870,Number2 = 215,Number3 = 0,Number4 = 0,},
{BoxID = 22,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 910,Number2 = 225,Number3 = 0,Number4 = 0,},
{BoxID = 23,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 950,Number2 = 235,Number3 = 0,Number4 = 0,},
{BoxID = 24,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 990,Number2 = 245,Number3 = 0,Number4 = 0,},
{BoxID = 25,Item1 = 4,Item2 = 3,Item3 = 0,Item4 = 0,Number1 = 1030,Number2 = 255,Number3 = 0,Number4 = 0,},
}


function getBoxID(id) --宝箱ID
	starbox = HuperziaRewardData[id].BoxID
	return starbox;
end

function getItemType(id,itemRewardType) --宝箱奖励物品类型(itemRewardType ItemAwards1,ItemAwards2,ItemAwards3)
	local rewardType = 0	
	
	if itemRewardType == 0 then 
		rewardType = HuperziaRewardData[id].Item1
	elseif 	itemRewardType == 1 then 
		rewardType = HuperziaRewardData[id].Item2
	
	elseif 	itemRewardType == 2 then 
		rewardType = HuperziaRewardData[id].Item3
	else 
		rewardType = HuperziaRewardData[id].Item4	
	end		
	
	if rewardType == 0 then
		return 0;
	end	
	
	resid = item[rewardType].itemType
	return resid;
end

function getItemNumber(id,itemRewardType) --掉落物品数量(itemRewardType ItemNumeber1,ItemNumeber2,ItemNumeber3)
	local number = 0	
	
	if itemRewardType == 0 then 
		number = HuperziaRewardData[id].Number1
	elseif 	itemRewardType == 1 then 
		number = HuperziaRewardData[id].Number2
	elseif  itemRewardType == 2 then 
		number = HuperziaRewardData[id].Number3
	else
		number = HuperziaRewardData[id].Number4
	end				
	return number;
end
