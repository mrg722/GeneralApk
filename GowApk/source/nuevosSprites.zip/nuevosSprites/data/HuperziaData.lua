--region HuperziaData.lua
--Date 2015/12/17
--此文件由[BabeLua]插件自动生成

local item = {
	{itemType=1,Name="生命药",},
	{itemType=2,Name="能量药",},
	{itemType=3,Name="金币",},
	{itemType=4,Name="红魂",},
	{itemType=5,Name="经验",},
	{itemType=6,Name="拳套碎片1",},
	{itemType=7,Name="拳套碎片2",},
	{itemType=8,Name="拳套碎片3",},
	{itemType=9,Name="电光链碎片1",},
	{itemType=10,Name="电光链碎片2",},
	{itemType=11,Name="电光链碎片3",},
	{itemType=12,Name="电光链碎片4",},
	{itemType=13,Name="电光链碎片5",},
	{itemType=14,Name="电光链碎片6",},
}

---pices 层数, maxScore 积分上限, recommentFight 推荐战斗力,iconState (cocostudio 对应图标状态),picesNameState(cocostudio 对应名字状态),
--- ResID1 掉落物品ID , Number1 掉落物品数量,ResProplity1 掉落物品概率,TaskInformationState  星级条件描述
--ResType1为0时是不掉落，非零掉落物品类型
local HuperziaScoreData = {
{pices = 901,recommentFight = 4000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 902,recommentFight = 4500,iconState = 17,picesNameState = 10,TaskInformationState = 2,},
{pices = 903,recommentFight = 6100,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 904,recommentFight = 7150,iconState = 16,picesNameState = 9,TaskInformationState = 4,},
{pices = 905,recommentFight = 8200,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 906,recommentFight = 9250,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 907,recommentFight = 11000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 908,recommentFight = 13000,iconState = 18,picesNameState = 11,TaskInformationState = 3,},
{pices = 909,recommentFight = 16500,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 910,recommentFight = 20000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 911,recommentFight = 21000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 912,recommentFight = 23500,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 913,recommentFight = 29500,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 914,recommentFight = 28500,iconState = 16,picesNameState = 9,TaskInformationState = 4,},
{pices = 915,recommentFight = 32000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 916,recommentFight = 36000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 917,recommentFight = 44500,iconState = 17,picesNameState = 10,TaskInformationState = 2,},
{pices = 918,recommentFight = 51000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 919,recommentFight = 56000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 920,recommentFight = 60000,iconState = 15,picesNameState = 8,TaskInformationState = 1,},
{pices = 921,recommentFight = 31000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 922,recommentFight = 32000,iconState = 18,picesNameState = 11,TaskInformationState = 3,},
{pices = 923,recommentFight = 33000,iconState = 16,picesNameState = 9,TaskInformationState = 4,},
{pices = 924,recommentFight = 34000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 925,recommentFight = 35000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 926,recommentFight = 36000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 927,recommentFight = 37000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 928,recommentFight = 38000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 929,recommentFight = 39000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 930,recommentFight = 40000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 931,recommentFight = 41000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 932,recommentFight = 42000,iconState = 17,picesNameState = 10,TaskInformationState = 2,},
{pices = 933,recommentFight = 43000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 934,recommentFight = 44000,iconState = 16,picesNameState = 9,TaskInformationState = 4,},
{pices = 935,recommentFight = 45000,iconState = 15,picesNameState = 8,TaskInformationState = 1,},
{pices = 936,recommentFight = 46000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 937,recommentFight = 47000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 938,recommentFight = 48000,iconState = 18,picesNameState = 11,TaskInformationState = 3,},
{pices = 939,recommentFight = 49000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 940,recommentFight = 50000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 941,recommentFight = 51000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 942,recommentFight = 52000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 943,recommentFight = 53000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 944,recommentFight = 54000,iconState = 16,picesNameState = 9,TaskInformationState = 4,},
{pices = 945,recommentFight = 55000,iconState = 14,picesNameState = 7,TaskInformationState = 0,},
{pices = 946,recommentFight = 56000,iconState = 13,picesNameState = 6,TaskInformationState = 6,},
{pices = 947,recommentFight = 57000,iconState = 17,picesNameState = 10,TaskInformationState = 2,},
{pices = 948,recommentFight = 58000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
{pices = 949,recommentFight = 59000,iconState = 15,picesNameState = 8,TaskInformationState = 1,},
{pices = 950,recommentFight = 60000,iconState = 13,picesNameState = 19,TaskInformationState = 5,},
}

---千层塔关卡
function getPices(id)
	gate = HuperziaScoreData[id].pices
	return gate;
end

---千层塔关卡每关总积分
function getPicesOfScores(id)
	scores = HuperziaScoreData[id].maxScore
	return scores;
end

---千层塔关卡推荐战斗力
function getRecommentFight(id)
	fight = HuperziaScoreData[id].recommentFight
	return fight;
end

---千层塔关卡对应战斗Icon状态<cocostudio 动画状态>
function getIconState(id)
	iconstate = HuperziaScoreData[id].iconState
	return iconstate;
end

---千层塔关卡对应战斗Icon状态被选中状态<cocostudio 动画状态>
function getIconSelectState(id)
	currentState = HuperziaScoreData[id].iconState
	local iconselectstate = 0;

	if currentState == 13 then
		iconselectstate = 0
	elseif currentState == 14 then
		iconselectstate = 1
	elseif currentState == 15 then
		iconselectstate = 2
	elseif currentState == 16 then
		iconselectstate = 3
	elseif currentState == 17 then
		iconselectstate = 4
	elseif currentState == 18 then
		iconselectstate = 5
	end
	return iconselectstate;
end


---千层塔关卡对应战斗名字状态<cocostudio 动画状态>
function getPicesNameState(id)
	picename = HuperziaScoreData[id].picesNameState
	return picename;
end

function getResType1(id) --掉落物品类型1
	dropItemType1 = HuperziaScoreData[id].ResType1
	if dropItemType1 == 0 then
		return 0;
	end	
	resid = item[dropItemType1].itemType
	return resid;
end

function getResType2(id) --掉落物品类型2
	dropItemType2 = HuperziaScoreData[id].ResType2
	if dropItemType2 == 0 then
		return 0;
	end	
	resid = item[dropItemType2].itemType
	return resid;
end

function getNumber1(id) -- 物品1数量
	num1 = HuperziaScoreData[id].Number1
	return num1;
end

function getNumber2(id) -- 物品2数量
	num2 = HuperziaScoreData[id].Number2
	return num2;
end

function getTaskNameActionState(id) -- 积分条件cocoStudio 动画状态
	score1 = HuperziaScoreData[id].TaskInformationState
	return score1;
end

function getHuperziaBasicScore()----每层塔保底积分
	return 700;
end

function getPlayerVIPScore(picesOfScore)---VIP额外奖励积分 <picesOfScore 每层总积分>
	score = picesOfScore / 6
	return score;
end

function getRandomScore() ---随机积分
	return 50;
end

----HuperziaPassGateTime = 1,//千层塔通关时间1
----HuperziaHeroCurrentHP,//主角剩余血量百分比2
----HuperziaUseDrugNumber,//使用药品3
----HuperziaProtectActorHP,//护送目标血量剩余百分比	4
----HuperziaGuardActorHP,//守护目标血量剩余百分比5
----HuperziaOpenBoxNumber,//开启宝箱个数6
----HuperziaComboTimes,//连击次数7
----HuperziaTimelimitKillEnemy,//千层塔限时击杀指定敌人<敌人ID specil[1]>8
----HuperziaBehitFromTropTimes,//被机关攻击次数9
----HuperziaBehitTimes,//被攻击次数10
----HuperziaKillAllEnemy,//击杀全部敌人11
----HuperziaFinishQTETimes,//完成QTE次数12
----HuperziaUseTropTimes//使用机关次数13

function getTaskRewardScore(currentValue,taskType,maxValue,minValue)
	local scores = 0
	if taskType == 1 or taskType == 3 or taskType == 8 or taskType == 9 or taskType == 10 then
		if currentValue < minValue then
			return 600;
		elseif currentValue > maxValue-minValue then
			return 0;				
		end
		scores = (1 - (currentValue-minValue) / (maxValue-2*minValue) )* 600
		return scores;
	elseif taskType == 2 or taskType == 4 or taskType == 5 or taskType == 6 or taskType == 7 then
		if currentValue < minValue then
			return 0;
		elseif currentValue > maxValue-minValue then
			return 600;				
		end 
		scores = (1 - (maxValue-minValue-currentValue) / (maxValue-2*minValue) )* 600
		return scores;
	end
	return scores
end

function getFightRewardScore(currentValue,recommentFight) ----每个任务奖励的最大积分 <currentValue 当前 (时间:当前- 最佳)   , maxValue 最大值 (时间:最大- 最佳)>
	if currentValue/recommentFight < 0.8 then
	 return 0;
	elseif currentValue/recommentFight > 1.2 then	
	 return 500;
	end
	scores = (currentValue/recommentFight - 0.8 )/ 0.4 * 500
	return scores;
end

function getHuperziaSubMoney(times)--千层塔再次挑战消耗金币
	if times < 10 then
	 return times * 80 + 80;
	else 
	 return 880;
	 end
end

--endregion

