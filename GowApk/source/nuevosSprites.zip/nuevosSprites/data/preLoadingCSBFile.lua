--region preLoadingCSBFile.lua
--Date 2015/12/17
--此文件由[BabeLua]插件自动生成
--fileID界面序号 这个序号没有规则，需要预加载的可向后面累加。
local LoadingCSBFileData = {
{fileID = 1,	fileName = "uidata/GameHome.csb",				}, --主城界面
{fileID = 2,	fileName = "uidata/GamePlay.csb",				}, --战斗界面
{fileID = 3,	fileName = "uidata/GamePlay_Auto.csb",			}, --自动战斗界面
{fileID = 4,	fileName = "uidata/GameQTE.csb",				}, --QTE界面
{fileID = 5,	fileName = "uidata/GameSkill.csb",				}, --技能界面
{fileID = 6,	fileName = "uidata/Jiesuowuqijiemian.csb",		}, --武器计费点界面
{fileID = 7,	fileName = "uidata/QCT.csb",					}, --千层塔界面
{fileID = 8,	fileName = "uidata/Qiancengtashengli.csb",		}, --千层塔胜利界面
{fileID = 9,	fileName = "uidata/Wuqi.csb",					}, --武器界面
{fileID = 10,	fileName = "uidata/Xuanxiaoguan.csb",			}, --世界地图界面
{fileID = 11,	fileName = "uidata/Zhandoushengli.csb",			}, --普通结算界面
{fileID = 12,	fileName = "uidata/Zhandoushibai.csb",			}, --战斗失败界面
{fileID = 13,	fileName = "uidata/Zhandouwoyaobianqiang.csb",	}, --我要变强界面
{fileID = 14,	fileName = "uidata/Zhandouzhunbei.csb",			}, --战斗准备界面
{fileID = 15,	fileName = "uidata/Zhoukajiemian.csb",			}, --周卡界面
{fileID = 16,	fileName = "uidata/Zhoukameirifanli.csb",		}, --周卡返利界面
{fileID = 17,	fileName = "uidata/GameLoading.csb",			}, --加载界面
{fileID = 18,	fileName = "uidata/GameGateMode.csb",			}, --关卡模式界面
{fileID = 19,	fileName = "uidata/Dilog.csb",					}, --剧情界面
{fileID = 20,	fileName = "uidata/DirenBoShu.csb",				}, --敌人波数界面
{fileID = 21,	fileName = "uidata/Jinbijiesuanjiemian.csb",	}, --副本结算界面
{fileID = 22,	fileName = "uidata/Shengjijiemian.csb",			}, --升级界面
}

---预加载CSB文件总数
function getMaxCsbFileNumber()	
	return table.getn(LoadingCSBFileData);
end

---当前csb文件名称
function getCsbFlieName(id)
	local name = LoadingCSBFileData[id].fileName
	return name;
end
--endregion

