----序号(ID)|怪物种类(Type)|名字(Name)|  基础生命(HP)|生命成长(HPIndex)|基础攻击(Att)|攻击成长(AttIndex)|基础防御(Def)|防御成长(DefIndex)|攻击1范围(AttakFont1)|攻击2范围(AttakFont2)|攻击模式(Mode)|视野范围(LookFont)|血条模式(BloodMode)|攻击1独立攻击框(Attack1RedRectState)|攻击1独立攻击框位移(Attack1RedRectMove)|攻击2独立攻击框(Attack2RedRectState)|攻击1独立攻击框位移(Attack2RedRectMove)|反击概率(AttackPropblity)|霸体(Invality)|攻击间隔(AttackWaiTime) headState(cocostudio GameQTE.csd状态号)
EnemyProperty = {
--普通小兵--
{ID=1,Type="骷髅兵",					Name = "",           		 			RedSouls=6,      StrongType=0,	HP=2000,   HPIndex=200,		Att=80,		AttIndex=16,	Def=22,	DefIndex=8,	AttakFont1 = 215,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=2,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=2,Type="骷髅盾兵",					Name = "",           		 			RedSouls=6,      StrongType=0,	HP=3000,   HPIndex=300,		Att=70,		AttIndex=14,	Def=22,	DefIndex=8,	AttakFont1 = 215,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=2,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=3,Type="钻地怪",    				Name = "",           		 			RedSouls=6,      StrongType=0,	HP=2000,   HPIndex=200,		Att=80,		AttIndex=16,	Def=22,	DefIndex=8,	AttakFont1 = 190,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=2,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=4,Type="象怪",      				Name = "",            		 			RedSouls=6,      StrongType=0,	HP=2400,   HPIndex=240,		Att=90,		AttIndex=18,	Def=22,	DefIndex=8,	AttakFont1 = 230,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=2,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=5,Type="半人马",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=2800,   HPIndex=280,		Att=100,	AttIndex=20,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 2,     AttakFont2 = 300,	AttackWarning2 = 3,     Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=6,Type="链球怪1",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=3400,   HPIndex=340,  	Att=140,	AttIndex=28,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=7,Type="链球怪2",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=3400,   HPIndex=340,  	Att=140,	AttIndex=28,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 1,	LookFont = 800,	BloodMode = 0,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=8,Type="美杜莎1",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=3000,   HPIndex=300,   	Att=130,	AttIndex=26,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 0,     AttakFont2 = 320,	AttackWarning2 = 1,     Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
--精英A，有QTE，绿名，4倍初始血量，4倍成长血量，全属性小提升--
{ID=9,Type="精英骷髅兵",  				Name = "精英,0,255,0",  	    		RedSouls=6,      StrongType=1,	HP=8000,   HPIndex=800,  	Att=80,		AttIndex=20,	Def=22,	DefIndex=8,	AttakFont1 = 215,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=10,Type="精英骷髅盾兵",				Name = "精英,0,255,0",					RedSouls=6,      StrongType=1,	HP=12000,  HPIndex=1200,	Att=70,		AttIndex=17,	Def=22,	DefIndex=8,	AttakFont1 = 215,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=11,Type="精英钻地怪",    			Name = "精英,0,255,0",  				RedSouls=6,      StrongType=1,	HP=8000,   HPIndex=800,		Att=80,		AttIndex=20,	Def=22,	DefIndex=8,	AttakFont1 = 190,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=12,Type="精英象怪",      			Name = "精英,0,255,0",            		RedSouls=6,      StrongType=1,	HP=9600,   HPIndex=960,		Att=90,		AttIndex=23,	Def=22,	DefIndex=8,	AttakFont1 = 230,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=13,Type="精英半人马",    			Name = "精英,0,255,0",      			RedSouls=12,     StrongType=1,	HP=11200,  HPIndex=1120,	Att=100,	AttIndex=26,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 2,     AttakFont2 = 300,	AttackWarning2 = 3,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/RenMaQTE/renma1",			spineState = "fenjingdonghua1",headState = 0,},
{ID=14,Type="精英链球怪",   		 	Name = "精英,0,255,0",          		RedSouls=12,     StrongType=1,	HP=13600,  HPIndex=1360,  	Att=140,	AttIndex=38,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/ChainfattyQTE/Chainfatty1",	spineState = "fenjingdonghua1",headState = 1,},
{ID=15,Type="精英蛇发女妖",    		 	Name = "精英,0,255,0",       			RedSouls=12,     StrongType=1,	HP=12000,  HPIndex=1200,   	Att=130,	AttIndex=35,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 0,     AttakFont2 = 320,	AttackWarning2 = 1,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/medsuaQTE/medusa1",		  	spineState = "meidusha1",		 headState = 2,},
--统领A，红名，6倍初始血量，6倍成长血量，全属性中提升，特定属性大提升--
{ID=16,Type="骷髅兵",  					Name = "统领,255,0,0",  	   			RedSouls=6,      StrongType=2,	HP=12000,  HPIndex=1200,  	Att=80,		AttIndex=24,	Def=22,	DefIndex=8,	AttakFont1 = 215,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 1, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=17,Type="骷髅盾兵",					Name = "统领,255,0,0",					RedSouls=6,      StrongType=2,	HP=18000,  HPIndex=1800,	Att=70,		AttIndex=20,	Def=22,	DefIndex=8,	AttakFont1 = 215,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=18,Type="钻地怪",    				Name = "统领,255,0,0",  				RedSouls=6,      StrongType=2,	HP=12000,  HPIndex=1200,	Att=80,		AttIndex=24,	Def=22,	DefIndex=8,	AttakFont1 = 190,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 1, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=19,Type="象怪",      				Name = "统领,255,0,0",           	 	RedSouls=6,      StrongType=2,	HP=14400,  HPIndex=1440,	Att=90,		AttIndex=26,	Def=22,	DefIndex=8,	AttakFont1 = 230,	AttackWarning1 = -1,    AttakFont2 = 0,		AttackWarning2 = -1,    Mode = 0,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 1, 	AttackWaiTime = 200,	DieEffectState = 46, PlaySpeed = 1.5, spineName = "",spineState = "",headState = -1,},
{ID=20,Type="半人马",    				Name = "统领,255,0,0",      			RedSouls=12,     StrongType=2,	HP=16800,  HPIndex=1680,	Att=100,	AttIndex=32,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 2,     AttakFont2 = 300,	AttackWarning2 = 3,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/RenMaQTE/renma1",			spineState = "fenjingdonghua1",headState = 0,},
{ID=21,Type="链球怪",    				Name = "统领,255,0,0",          		RedSouls=12,     StrongType=2,	HP=20400,  HPIndex=2040,  	Att=140,	AttIndex=48,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/ChainfattyQTE/Chainfatty1",	spineState = "fenjingdonghua1",headState = 1,},
{ID=22,Type="蛇发女妖",     			Name = "统领,255,0,0",      			RedSouls=12,     StrongType=2,	HP=18000,  HPIndex=1800,   	Att=130,	AttIndex=38,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 0,     AttakFont2 = 320,	AttackWarning2 = 1,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=20,		Invality = 1, 	AttackWaiTime = 1,	    DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/medsuaQTE/medusa1",		  	spineState = "meidusha1",		 headState = 2,},
--世界BOSS，8倍血量，全属性中提升--
{ID=23,Type="半人马",    				Name = "",      						RedSouls=12,     StrongType=3,	HP=22400,  HPIndex=2240,	Att=100,	AttIndex=48,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 2,     AttakFont2 = 300,	AttackWarning2 = 3,     Mode = 2,	LookFont = 999,	BloodMode = 1,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/RenMaQTE/renma1",			spineState = "fenjingdonghua1",headState = 0,},
{ID=24,Type="链球怪",    				Name = "",          					RedSouls=12,     StrongType=3,	HP=27200,  HPIndex=2720,  	Att=140,	AttIndex=68,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 2,	LookFont = 999,	BloodMode = 1,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/ChainfattyQTE/Chainfatty1",	spineState = "fenjingdonghua1",headState = 1,},
{ID=25,Type="蛇发女妖",     			Name = "",      						RedSouls=12,     StrongType=3,	HP=24000,  HPIndex=2400,    Att=130,	AttIndex=62,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 0,     AttakFont2 = 320,	AttackWarning2 = 1,     Mode = 2,	LookFont = 999,	BloodMode = 1,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/medsuaQTE/medusa1",		  	spineState = "meidusha1",		 headState = 2,},
--前期专用怪物，普通小兵，拥有QTE--
{ID=26,Type="半人马",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=2800,   HPIndex=280,		Att=100,	AttIndex=20,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 2,     AttakFont2 = 300,	AttackWarning2 = 3,     Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/RenMaQTE/renma1",			spineState = "fenjingdonghua1",headState = 0,},
{ID=27,Type="链球怪1",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=3400,   HPIndex=340,  	Att=140,	AttIndex=28,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 0,	LookFont = 800,	BloodMode = 0,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/ChainfattyQTE/Chainfatty1",	spineState = "fenjingdonghua1",headState = 1,},
{ID=28,Type="链球怪2",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=3400,   HPIndex=340,  	Att=140,	AttIndex=28,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 1,	LookFont = 800,	BloodMode = 0,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/ChainfattyQTE/Chainfatty1",	spineState = "fenjingdonghua1",headState = 1,},
{ID=29,Type="美杜莎1",    				Name = "",            		 			RedSouls=12,     StrongType=0,	HP=3000,   HPIndex=300,   	Att=130,	AttIndex=26,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 0,     AttakFont2 = 320,	AttackWarning2 = 1,     Mode = 1,	LookFont = 800,	BloodMode = 0,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/medsuaQTE/medusa1",		  	spineState = "meidusha1",		headState = 2,},
--真·世界BOSS，15倍血量（骷髅兵计算），全属性大提升--
{ID=30,Type="触手怪",    				Name = "",      						RedSouls=12,     StrongType=3,	HP=30000,  HPIndex=3000,	Att=140,	AttIndex=60,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 6,     AttakFont2 = 300,	AttackWarning2 = 7,     Mode = 2,	LookFont = 999,	BloodMode = 1,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/PoseidonBabyQTE/poseidonbaby1",spineState = "fenjingdonghua1",headState = 4,}, 
{ID=31,Type="泰坦巨人",    				Name = "",          					RedSouls=12,     StrongType=3,	HP=30000,  HPIndex=3000,  	Att=140,	AttIndex=60,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 10,    AttakFont2 = 470,	AttackWarning2 = 11,    Mode = 2,	LookFont = 999,	BloodMode = 1,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",spineState = "",headState = 3,},
{ID=32,Type="波塞冬",     				Name = "",      						RedSouls=12,     StrongType=3,	HP=30000,  HPIndex=3000,   	Att=140,	AttIndex=60,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 8,     AttakFont2 = 320,	AttackWarning2 = 9,     Mode = 2,	LookFont = 999,	BloodMode = 1,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "spine/PoseidonQTE/poseidon1",		spineState = "fenjingdonghua1",headState = 5,},
--精英B，无QTE，绿名，4倍初始血量，4倍成长血量，全属性小提升--
{ID=33,Type="精英半人马",    			Name = "精英,0,255,0",      			RedSouls=12,     StrongType=1,	HP=11200,  HPIndex=1120,	Att=100,	AttIndex=26,	Def=22,	DefIndex=8,	AttakFont1 = 300,	AttackWarning1 = 2,     AttakFont2 = 300,	AttackWarning2 = 3,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=16,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",	spineState = "",headState = -1,},
{ID=34,Type="精英链球怪",   		 	Name = "精英,0,255,0",          		RedSouls=12,     StrongType=1,	HP=13600,  HPIndex=1360,  	Att=140,	AttIndex=38,	Def=22,	DefIndex=8,	AttakFont1 = 260,	AttackWarning1 = 4,     AttakFont2 = 470,	AttackWarning2 = 5,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=12,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",	spineState = "",headState = -1,},
{ID=35,Type="精英蛇发女妖",    		 	Name = "精英,0,255,0",       			RedSouls=12,     StrongType=1,	HP=12000,  HPIndex=1200,   	Att=130,	AttIndex=35,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = 0,     AttakFont2 = 320,	AttackWarning2 = 1,     Mode = 2,	LookFont = 800,	BloodMode = 2,	AttackPropblity=20,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",	spineState = "",headState = -1,},
--NPC,36护送女，37雅典娜，38宙斯--
{ID=36,Type="NPC",    		 			Name = "",       						RedSouls=12,     StrongType=4,	HP=1600,   HPIndex=400,   	Att=175,	AttIndex=35,	Def=40,	DefIndex=8, AttakFont1 = 280,	AttackWarning1 = -1,    AttakFont2 = 320,	AttackWarning2 = -1,    Mode = 2,	LookFont = 800,	BloodMode = 1,	AttackPropblity=8,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",	spineState = "",headState = 6,},
{ID=37,Type="NPC",    		 			Name = "",       						RedSouls=12,     StrongType=4,	HP=1600,   HPIndex=400,   	Att=175,	AttIndex=35,	Def=40,	DefIndex=8, AttakFont1 = 280,	AttackWarning1 = -1,    AttakFont2 = 320,	AttackWarning2 = -1,    Mode = 2,	LookFont = 800,	BloodMode = 1,	AttackPropblity=8,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",	spineState = "",headState = 7,},
{ID=38,Type="NPC",    		 			Name = "",       						RedSouls=12,     StrongType=4,	HP=22000,  HPIndex=2200,    Att=175,	AttIndex=35,	Def=22,	DefIndex=8,	AttakFont1 = 280,	AttackWarning1 = -1,    AttakFont2 = 320,	AttackWarning2 = -1,    Mode = 2,	LookFont = 800,	BloodMode = 1,	AttackPropblity=8,		Invality = 0, 	AttackWaiTime = 200,	DieEffectState = 68, PlaySpeed = 1.5, spineName = "",	spineState = "",headState = 8,},

}


function getEnemyID(id)	
	currentEnemyID = EnemyProperty[id].ID
	return currentEnemyID;
end

function getEnemyName(id)	
   EnemyName = EnemyProperty[id].Name
   return EnemyName;
end 

function getEnemyBasicHP(id)-----敌人生命基础值	
	basicHP = EnemyProperty[id].HP		
	return basicHP;
end

function getEnemyBasicHPIndex(id)----敌人生命成长值	
	IndexHP = EnemyProperty[id].HPIndex	
	return IndexHP;
end


function EnemyHPValue(level,id) ---敌人生命成长公式	
	basicHP = getEnemyBasicHP(id)---基础值
	Index = getEnemyBasicHPIndex(id) -----成长系数
	maxHP = (level * Index) + basicHP
	return maxHP;
end

function getEnemyBasicAttack(id)-----敌人攻击基础值	
	baicAtt = EnemyProperty[id].Att	
	return baicAtt;
end

function getEnemyBasicAttackIndex(id)----敌人攻击成长值	
	indexAtt = EnemyProperty[id].AttIndex	
	return indexAtt;
end

function EnemyAttackValue(level,id) ---敌人攻击成长公式	
	baicAtt = getEnemyBasicAttack(id)---基础值
	indexAtt = getEnemyBasicAttackIndex(id) -----成长系数
	return level * indexAtt + baicAtt;
end

function getEnemyBasicDef(id)-----敌人防御基础值	
	baicDef = EnemyProperty[id].Def	
	return baicDef;
end

function getEnemyBasicDefIndex(id)----敌人攻击成长值	
	IndexDef = EnemyProperty[id].DefIndex	
	return IndexDef;
end

function EnemyDefValue(level,id) ---敌人攻击成长公式	
	baicDef = getEnemyBasicDef(id)---基础值
	IndexDef = getEnemyBasicDefIndex(id) -----成长系数
	return level * IndexDef + baicDef;
end

function EnemyAttackFont1(id) --------攻击1攻击范围	
	font  = EnemyProperty[id].AttakFont1
	return font;	
end

function EnemyAttackWarning1(id)	--攻击1预警状态号
	attackWarning1 = EnemyProperty[id].AttackWarning1
	return attackWarning1;
end

function EnemyAttackFont2(id) -------攻击2攻击范围	
	font  = EnemyProperty[id].AttakFont2
	return font;	
end

function EnemyAttackWarning2(id)	--攻击2预警状态号
	attackWarning2 = EnemyProperty[id].AttackWarning2
	return attackWarning2;
end
	
function EnemyLookFont(id) ---- 视野范围	
   font = EnemyProperty[id].LookFont
   return font;
end

function EnemyBloodMode(id) -----血条模式（0是常规血条，1是世界BOSS血条，2是3管小血条）	
	modes = EnemyProperty[id].BloodMode
	return modes;
end

function EnemyAttackPropblity(id,level) ------反击概率
	if EnemyProperty[id].AttackPropblity == 2 then 
		propblity = EnemyProperty[id].AttackPropblity + level*0.0008
		return propblity;
	end
	propblity = EnemyProperty[id].AttackPropblity
	return propblity;
end

function EnemyModeValue(id) -----敌人模式(0 攻击1  1 攻击2  2攻击1+攻击2)	
	enemyMode = EnemyProperty[id].Mode
	return enemyMode;
end

function EnemyIsInvality(id) -----全程霸体 0没有霸体 1有霸体	
	local superArmor = EnemyProperty[id].Invality
	if superArmor == 0 then
		return false;	
	end
	return true;
end

function EnemyAttackWaiTime(id) ------攻击间隔时间（单位 ms）	
	times = EnemyProperty[id].AttackWaiTime
	return times;
end

function getQTESpineFileName(id)---动画编辑器精灵号(对应骨骼文件)	
	fileName = EnemyProperty[id].spineName
	return fileName	
end

function getQTESpineFileState(id)---动画编辑器精灵号(对应骨骼动画状态)
	local randomNum = math.random(0,2);
	if randomNum == 1 then
		if id == 30 then ---触手怪
			return "fenjingdonghua6";
		elseif id == 31 then ---泰坦巨人
			return "fenjingdonghua5";
		elseif id == 32 then ---波塞冬
			return "fenjingdonghua9";
		elseif id == 14 or id == 21 or id == 24 or id == 27 or id == 28 then ---练球怪
			return "fenjingdonghua8";
		end
	end
	fileState = EnemyProperty[id].spineState
	return fileState	
end

function getQTECocoStudioState(id)-----cocostudio GameQTE.csd 状态号	
	cocostudioState = EnemyProperty[id].headState
	return cocostudioState
end

function getStrongType(id)	--强度类型 0普通 1精英 2变异 3世界BOSS 4NPC
	strongType = EnemyProperty[id].StrongType
	return strongType;
end

function getRedSouls(id)	--红魂轨迹数量
	redSouls = EnemyProperty[id].RedSouls
	return redSouls;
end

function getPlaySpeed(id)	--QTE整体播放速度
	playSpeed = EnemyProperty[id].PlaySpeed
	return playSpeed;
end

function getScale(id,BossType,BossAttackType)	--圆形预警缩放比例
local scale = 1.0
	if (BossType == 45 or BossType == 112) and BossAttackType == 39 then ----美杜莎		
		scale = 0.67;		
	elseif	BossType == 35 or BossType == 110 then ----人马		
        if BossAttackType == 40 then
			scale = 0.75;	
         end		
	elseif	BossType == 64 and BossAttackType == 39 then ----波塞冬		
			scale = 0.8;					
	elseif	BossType == 64 and BossAttackType == 40 then ----波塞冬 闪电		
			scale = 0.7;				
	end
	return scale;
end

function getDieEffectState(id)	--获取死亡特效状态号（乐堂）
	dieEffectState = EnemyProperty[id].DieEffectState
	return dieEffectState;
end

function EnemyExpValue(heroLevel,enemyLevel,ID) ---敌人奖励经验成长公式
local strongType = EnemyProperty[ID].StrongType
local Exp = 0
--根据怪物强度计算基础经验
	if strongType == 1 or strongType == 2 then  
		Exp = enemyLevel*20;
	elseif strongType == 0 then 
		Exp = enemyLevel*10;
	elseif strongType == 3 then 
		Exp = enemyLevel*30;
	end
--根据主角与怪物等级进行经验衰减
	if heroLevel <= enemyLevel then 
		return Exp;
	elseif heroLevel - enemyLevel >= 9 then 
		return Exp*0.2;
	end
	local integer,discons = math.modf(Exp * (1 - 0.1*(heroLevel - enemyLevel)));	
	return integer;
end

function EnemySoulsValue(heroLevel,enemyLevel,ID) ---敌人掉落红魂成长公式
local strongType = EnemyProperty[ID].StrongType
local souls = 0
	if strongType == 1 or strongType == 2 then 
		if enemyLevel<30 then
			souls = enemyLevel*2.67+40;
		elseif enemyLevel<60 then
			souls = enemyLevel*10-180;
		elseif enemyLevel<101 then
			souls = enemyLevel*3+240;
		end
	elseif strongType == 0 then 
		if enemyLevel<30 then
			souls = enemyLevel*2.67+40;
		elseif enemyLevel<60 then
			souls = enemyLevel*10-180;
		elseif enemyLevel<101 then
			souls = enemyLevel*3+240;
		end
	elseif strongType == 3 then 
		if enemyLevel<30 then
			souls = enemyLevel*2.67+40;
		elseif enemyLevel<60 then
			souls = enemyLevel*10-180;
		elseif enemyLevel<101 then
			souls = enemyLevel*3+240;
		end
	end
	
	if heroLevel <= enemyLevel then
		return souls;
	elseif heroLevel - enemyLevel >= 9 then 
		return souls*0.2;
	end	
	local integer,discons = math.modf(souls * (1 - 0.1*(heroLevel - enemyLevel)));	
	return integer;
end

function EnemyMoneyValue(level,ID) ---敌人掉落金币数量
local strongType = EnemyProperty[ID].StrongType
	if strongType == 1 or strongType == 2 then 
		return 10;
	elseif strongType == 0 then 
		return 10;
	elseif strongType == 3 then 
		return 10;
	end
	return 0;
end

function EnemyMoneyProbability(level,ID) --- 金币掉落几率
local strongType = EnemyProperty[ID].StrongType
	if strongType == 1 or strongType == 2 then 
		return 3;
	elseif strongType == 0 then 
		return 3;
	elseif strongType == 3 then 
		return 3;
	end
	return 0;
end

function EnemyHPProbability(level,ID) --- 生命药掉落几率
local strongType = EnemyProperty[ID].StrongType
	if strongType == 1 or strongType == 2 then 
		return 1;
	elseif strongType == 0 then 
		return 1;
	elseif strongType == 3 then 
		return 1;
	end
	return 0;
end

function EnemyMPProbability(level,ID) --- 能量药掉落几率
local strongType = EnemyProperty[ID].StrongType
	if strongType == 1 or strongType == 2 then 
		return 1;
	elseif strongType == 0 then 
		return 1;
	elseif strongType == 3 then 
		return 1;
	end
	return 0;
end

---敌人掉落物品概率统筹 itemType <0 金币 1 血药 2 蓝药 3 经验 4红魂>	
---heroLevel 主角当前等级
---enemyLevel 敌人当前等级
---ID 敌人属性表里的哪一个敌人
function getEnemyDropItem(itemType,heroLevel,enemyLevel,ID)
	local dropProp = math.random(0,100);--随机数
	local noDropProp = 95;--不掉率
	local moneyProp = EnemyMoneyProbability(enemyLevel,ID);--金币掉率
	local HPProp = EnemyHPProbability(enemyLevel,ID); --生命药概率
	local MPProp = EnemyMPProbability(enemyLevel,ID); --能量药概率
	local dropNum = 0;
	
	if itemType == 0 and (dropProp >= noDropProp and dropProp < noDropProp + moneyProp) then --金币	掉落数量
		 dropNum = EnemyMoneyValue(enemyLevel,ID);		
	elseif itemType == 1 and ((dropProp >= noDropProp + moneyProp) and (dropProp < noDropProp + moneyProp + HPProp))then --血药 掉落数量
		 dropNum = 1;		
	elseif itemType == 2 and ((dropProp >= noDropProp + moneyProp + HPProp) and (dropProp < noDropProp + moneyProp + HPProp + MPProp))then --蓝药 掉落数量
		 dropNum = 1;		
	elseif itemType == 3 then --经验
		 dropNum = EnemyExpValue(heroLevel,enemyLevel,ID);		
	elseif itemType == 4 then --红魂
		 dropNum = EnemySoulsValue(heroLevel,enemyLevel,ID);		
	end
	
	return dropNum;
end

