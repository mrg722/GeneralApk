WeepingData = {
{currentID = 1,  	gate = 101,  Exp = 144, Souls = 331,	Level = 1,},
{currentID = 2,  	gate = 111,  Exp = 336, Souls = 400,	Level = 2,},
{currentID = 3,  	gate = 121,  Exp = 552, Souls = 493,	Level = 4,},
{currentID = 4,  	gate = 131,  Exp = 1104, Souls = 634,	Level = 6,},
{currentID = 5,  	gate = 141,  Exp = 576, Souls = 230,	Level = 8,},
{currentID = 6,  	gate = 151,  Exp = 1680, Souls = 752,	Level = 10,},
{currentID = 7,  	gate = 161,  Exp = 3072, Souls = 1115,	Level = 12,},
{currentID = 8,  	gate = 171,  Exp = 3584, Souls = 1368,	Level = 14,},
{currentID = 9,  	gate = 181,  Exp = 2448, Souls = 832,	Level = 17,},
{currentID = 10,  gate = 191,  Exp = 7520, Souls = 2395,	Level = 20,},
{currentID = 11,  gate = 201,  Exp = 4320, Souls = 1460,	Level = 20,},
{currentID = 12,  gate = 211,  Exp = 3000, Souls = 835,		Level = 25,},
{currentID = 13,  gate = 221,  Exp = 5040, Souls = 1520,	Level = 30,},
{currentID = 14,  gate = 231,  Exp = 3080, Souls = 1080,	Level = 35,},
{currentID = 15,  gate = 241,  Exp = 10880, Souls = 4800,	Level = 40,},
{currentID = 16,  gate = 251,  Exp = 3600, Souls = 1344,	Level = 15,},
{currentID = 17,  gate = 261,  Exp = 3520, Souls = 1110,	Level = 20,},
{currentID = 18,  gate = 271,  Exp = 4600, Souls = 1531,	Level = 25,},
{currentID = 19,  gate = 281,  Exp = 8640, Souls = 2080,	Level = 30,},
{currentID = 20,  gate = 291,  Exp = 9240, Souls = 3480,	Level = 35,},
{currentID = 21,  gate = 301,  Exp = 3000, Souls = 2000,	Level = 40,},
{currentID = 22,  gate = 311,  Exp = 3000, Souls = 2000,	Level = 45,},
{currentID = 23,  gate = 321,  Exp = 3000, Souls = 2000,	Level = 50,},
{currentID = 24,  gate = 331,  Exp = 3000, Souls = 2000,	Level = 55,},
{currentID = 25,  gate = 341,  Exp = 3000, Souls = 2000,	Level = 60,},
{currentID = 26,  gate = 351,  Exp = 3000, Souls = 2000,	Level = 45,},
{currentID = 27,  gate = 361,  Exp = 3000, Souls = 2000,	Level = 55,},
{currentID = 28,  gate = 371,  Exp = 3000, Souls = 2000,	Level = 65,},
{currentID = 29,  gate = 381,  Exp = 3000, Souls = 2000,	Level = 75,},
{currentID = 30,  gate = 391,  Exp = 3000, Souls = 2000,	Level = 99,},
}


function getWeepingDataLength() --数组长度（物品个数）
	return table.getn(WeepingData);
end

function getWeepingID(id) ----扫荡关卡ID
	 gateID = WeepingData[id].currentID
	return gateID
end

function getWeepingGate(id) ----扫荡关卡号
	 currentGate = WeepingData[id].gate
	return gate
end

function getWeepingGateExp(id,heroLevel) ----扫荡获得经验
	local currentExp = WeepingData[id].Exp
	local enemyLevel = WeepingData[id].Level
	if heroLevel <= enemyLevel then 
		return currentExp;
	elseif heroLevel - enemyLevel >= 9 then 
		return currentExp*0.2;
	end
	
	local integer,discons = math.modf(currentExp * (1 - 0.1*(heroLevel - enemyLevel)));	
	return integer;	
end

function getWeepingGateSouls(id,heroLevel) ----扫荡获得红魂
	local currentSouls = WeepingData[id].Souls
	local enemyLevel = WeepingData[id].Level
	if heroLevel <= enemyLevel then
		return currentSouls;
	elseif heroLevel - enemyLevel >= 9 then 
		return currentSouls*0.2;
	end	
	local integer,discons = math.modf(currentSouls * (1 - 0.1*(heroLevel - enemyLevel)));	
	return integer;
end
