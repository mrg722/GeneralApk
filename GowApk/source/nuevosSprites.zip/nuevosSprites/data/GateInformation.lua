-----------世界地图信息	  ID 关卡号, Fight 推荐战斗力, ResID1 掉落物品ID , Number1 掉落物品数量,ResProplity1 掉落物品概率,star1Name 星级条件描述,
local item = {
	{itemType=1,Name="生命药",},
	{itemType=2,Name="能量药",},
	{itemType=3,Name="金币",},
	{itemType=4,Name="红魂",},
	{itemType=5,Name="经验",},
	{itemType=6,Name="拳套碎片1",},
	{itemType=7,Name="拳套碎片2",},
	{itemType=8,Name="拳套碎片3",},
	{itemType=9,Name="电光链碎片1",},
	{itemType=10,Name="电光链碎片2",},
	{itemType=11,Name="电光链碎片3",},
	{itemType=12,Name="电光链碎片4",},
	{itemType=13,Name="电光链碎片5",},
	{itemType=14,Name="电光链碎片6",},
}

local WorldMapProperty = {
{ID=101,Fight=4520,	WeaponTYPE="物攻",		ResType1 = 4,	ResType2 = 0,Number1 = 100,	Number2 = 0,	ResProplity1 = 50,	ResProplity2 = 0,	star1Name = "消灭全部敌人",				star2Name = "连击数达到3次",			star3Name = "完成本关",},
{ID=111,Fight=4660,	WeaponTYPE="物攻",		ResType1 = 6,	ResType2 = 0,Number1 = 1,  	Number2 = 1,	ResProplity1 = 100, ResProplity2 = 0,	star1Name = "完成1次QTE杀敌",			star2Name = "完成1次二段跳",			star3Name = "击杀精英骷髅兵",},
{ID=121,Fight=4850,	WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 5,  	Number2 = 120,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭5个袭来的敌人",		star2Name = "成功守护雅典娜",			star3Name = "击杀精英钻地怪",},
{ID=131,Fight=5030,	WeaponTYPE="物攻",		ResType1 = 7,	ResType2 = 0,Number1 = 1,	Number2 = 1,	ResProplity1 = 100,	ResProplity2 = 0,	star1Name = "消灭2个象怪",				star2Name = "使用2次机关",				star3Name = "击杀精英蛇发女妖 ",},
{ID=141,Fight=5210,	WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 5,	Number2 = 140,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "开启3个宝箱",				star2Name = "不受到地火攻击",			star3Name = "击杀精英半人马",},
{ID=151,Fight=7300,	WeaponTYPE="物攻",		ResType1 = 8,	ResType2 = 0,Number1 = 1,	Number2 = 1,	ResProplity1 = 100,	ResProplity2 = 0,	star1Name = "2分20秒内完成本关",		star2Name = "开启1个宝箱",				star3Name = "击杀精英半人马",},
{ID=161,Fight=7950,	WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 5,	Number2 = 200,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭半人马守卫",			star2Name = "消灭9个钻地怪",			star3Name = "击杀BOSS凯龙",},
{ID=171,Fight=8060,	WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 5,	Number2 = 210,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "连击数达到8次",			star2Name = "受攻击次数少于20次",		star3Name = "消灭2个精英敌人",},
{ID=181,Fight=8300,	WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 7,	Number2 = 220,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "成功护送乌狄妮",			star2Name = "消灭8个埋伏的敌人",		star3Name = "击杀精英美杜莎",},
{ID=191,Fight=12530,WeaponTYPE="物攻",		ResType1 = 9,	ResType2 = 0,Number1 = 1,	Number2 = 1,	ResProplity1 = 100,	ResProplity2 = 0,	star1Name = "消灭精英美杜莎",			star2Name = "消灭7个盾牌兵",			star3Name = "击杀BOSS许德拉",},
{ID=201,Fight=13130,WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 7,	Number2 = 230,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "击杀精英象怪",				star2Name = "受攻击次数少于10次",		star3Name = "消灭全部敌人",},
{ID=211,Fight=14720,WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 7,	Number2 = 240,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "40秒内摧毁宙斯神像",		star2Name = "使用3次技能",				star3Name = "消灭7个盾牌兵",},
{ID=221,Fight=15020,WeaponTYPE="物攻",		ResType1 = 10,	ResType2 = 0,Number1 = 1,	Number2 = 1,	ResProplity1 = 100,	ResProplity2 = 0,	star1Name = "消灭8个钻地怪",			star2Name = "击杀钻地怪统领",			star3Name = "消耗生命药少于20个",},
{ID=231,Fight=15300,WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 7,	Number2 = 250,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "连击数达到10次",			star2Name = "开启3个宝箱",				star3Name = "不受到地刺攻击",},
{ID=241,Fight=19010,WeaponTYPE="物攻",		ResType1 = 3,	ResType2 = 4,Number1 = 9,	Number2 = 260,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "受攻击次数少于5次",		star2Name = "消灭2个精英敌人",			star3Name = "击杀BOSS美杜莎",},
{ID=251,Fight=14270,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 9,	Number2 = 270,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "击杀精英美杜莎",			star2Name = "消灭全部敌人",				star3Name = "连击数达到20次 ",},
{ID=261,Fight=14670,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 9,	Number2 = 280,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "3分20秒内消灭全部敌人",	star2Name = "开启1个宝箱",				star3Name = "受攻击次数少于20次",},
{ID=271,Fight=15100,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 9,	Number2 = 290,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "开启船舱大门",				star2Name = "消灭2个美杜莎",			star3Name = "击杀美杜莎统领",},
{ID=281,Fight=16580,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 11,	Number2 = 300,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭4个象怪",				star2Name = "消灭10个精英敌人",			star3Name = "守护雅典娜神像",},
{ID=291,Fight=18570,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 11,	Number2 = 310,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭全部敌人",				star2Name = "消灭4个美杜莎",			star3Name = "击杀BOSS波塞冬",},
{ID=301,Fight=20990,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 11,	Number2 = 320,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭10个骷髅兵",			star2Name = "击杀铁球怪统领",			star3Name = "消耗生命药少于10个",},
{ID=311,Fight=21420,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 11,	Number2 = 330,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭2个精英敌人",			star2Name = "成功护送乌狄妮",			star3Name = "击杀象怪统领",},
{ID=321,Fight=22480,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 11,	Number2 = 340,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "连击数达到10次",			star2Name = "消灭铁球怪统领",			star3Name = "受攻击次数少于20次",},
{ID=331,Fight=23540,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 13,	Number2 = 350,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "3分20秒内完成本关",		star2Name = "消灭5个精英敌人",			star3Name = "消耗生命药少于30个",},
{ID=341,Fight=24600,WeaponTYPE="魔攻",		ResType1 = 3,	ResType2 = 4,Number1 = 13,	Number2 = 360,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "击杀钻地怪统领",			star2Name = "击杀半人马统领",			star3Name = "击杀BOSS链球怪",},
{ID=351,Fight=32210,WeaponTYPE="物攻魔攻",	ResType1 = 3,	ResType2 = 4,Number1 = 13,	Number2 = 370,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭7个象怪",				star2Name = "击杀美杜莎统领",			star3Name = "连击数达到30次",},
{ID=361,Fight=35200,WeaponTYPE="物攻魔攻",	ResType1 = 1,	ResType2 = 2,Number1 = 5,	Number2 = 2,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "连击数达到20次",			star2Name = "开启3个宝箱",				star3Name = "不受到地刺攻击",},
{ID=371,Fight=39260,WeaponTYPE="物攻魔攻",	ResType1 = 3,	ResType2 = 4,Number1 = 15,	Number2 = 400,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭9个骷髅兵",			star2Name = "使用6次机关",				star3Name = "击杀半人马统领",},
{ID=381,Fight=44800,WeaponTYPE="物攻魔攻",	ResType1 = 1,	ResType2 = 2,Number1 = 7,	Number2 = 2,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "消灭3个精英敌人",			star2Name = "连击数达到30次",			star3Name = "30秒内摧毁宙斯神像",},
{ID=391,Fight=62190,WeaponTYPE="物攻魔攻",	ResType1 = 1,	ResType2 = 2,Number1 = 8,	Number2 = 3,	ResProplity1 = 50,	ResProplity2 = 50,	star1Name = "受攻击次数少于10次",				star2Name = "击杀半人马统领",			star3Name = "击杀BOSS泰坦巨人",},
{ID=711,Fight=50000,WeaponTYPE="物攻",		ResType1 = 11,	ResType2 = 0,Number1 = 1,	Number2 = 0,	ResProplity1 = 1,	ResProplity2 = 0,	star1Name = "",							star2Name = "",							star3Name = "",},
{ID=712,Fight=50000,WeaponTYPE="魔攻",		ResType1 = 11,	ResType2 = 0,Number1 = 1,	Number2 = 0,	ResProplity1 = 1,	ResProplity2 = 0,	star1Name = "",							star2Name = "",							star3Name = "",},
{ID=721,Fight=50000,WeaponTYPE="物攻",		ResType1 = 11,	ResType2 = 0,Number1 = 1,	Number2 = 0,	ResProplity1 = 1,	ResProplity2 = 0,	star1Name = "",							star2Name = "",							star3Name = "",},
{ID=722,Fight=50000,WeaponTYPE="魔攻",		ResType1 = 11,	ResType2 = 0,Number1 = 1,	Number2 = 0,	ResProplity1 = 1,	ResProplity2 = 0,	star1Name = "",							star2Name = "",							star3Name = "",},
}

function getResDataLength() --数组长度（物品个数）
	return table.getn(WorldMapProperty);
end

function getGate(id) --大地图关卡号
	gate = WorldMapProperty[id].ID
	return gate;
end

function getFight(id) --推荐战斗力
	fight = WorldMapProperty[id].Fight		
	return fight;
end

function getWeaponType(id)---推荐武器类型
	weapontypes = WorldMapProperty[id].WeaponTYPE
	return weapontypes;
end

function getResType(id,DropType) --掉落物品类型
	local dropItemType = 0
	if DropType == 0 then ----第一种物品
		dropItemType = WorldMapProperty[id].ResType1
	elseif DropType == 1 then ----第二种物品
		dropItemType = WorldMapProperty[id].ResType2
	end
	
	if dropItemType == 0 then
		return 0;
	end	
	
	resid = item[dropItemType].itemType
	return resid;
end

function getResNumber(id,DropType) --掉落物品数量
	local number = 0
	if DropType == 0 then ----第一种物品
		number = WorldMapProperty[id].Number1
	elseif DropType == 1 then ----第二种物品
		number = WorldMapProperty[id].Number2
	end			
	return number;
end

function getResPropty(id,DropType) --掉落物品概率
	local propty = 0
	if DropType == 0 then ----第一种物品
		propty = WorldMapProperty[id].ResProplity1
	elseif DropType == 1 then ----第二种物品
		propty = WorldMapProperty[id].ResProplity2
	end			
	return propty;
end

function getResName(id,DropType) --掉落物品名称
	local dropItemType = 0
	if DropType == 0 then ----第一种物品
		dropItemType = WorldMapProperty[id].ResType1
	elseif DropType == 1 then ----第二种物品
		dropItemType = WorldMapProperty[id].ResType2
	end
	
	if dropItemType == 0 then
		return 0;
	end	
	
	dropItemName = item[dropItemType].Name
	return dropItemName;
end

function getStarName(id,starType) -- 星级条件 (starType 0,1星条件 << 1,2星条件 << 2,3星条件)
	local starName = ""
	if starType == 0 then 
		starName = WorldMapProperty[id].star1Name
	elseif starType == 1 then 
		starName = WorldMapProperty[id].star2Name
	else
		starName = WorldMapProperty[id].star3Name
	end
	return starName;
end
