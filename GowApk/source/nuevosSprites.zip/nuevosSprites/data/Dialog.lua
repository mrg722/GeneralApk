--actionState(0--N,UI编辑器内状态号) 0 主角 1 怪物 2 半人马 3 链球怪 4 美杜莎 5 许德拉 6 波塞冬 7 泰坦巨人 8 雅典娜 9 乌狄尼
StoryDialog = {
{SDID = 1, actionState = 0,SDName = "战神",  		SDText = "这是哪里？好容易找到机会舒畅一把，你竟然还敢追来！？哈哈哈哈，现在的你早已不是有生命的活物了。由此一直向东，便能到达帝国的首都。这点残余还是留给你吧，没兴趣和你争！这里的妖魔不知受到什么东西的影响，变得非常狂暴，肆虐我的国家，我不得已才出面解决它们。",},
{SDID = 2, actionState = 1,SDName = "波塞冬",  		SDText = "人间与地狱穿越的出入口。这片遗迹位于西之魔王的统治范围下，想要斩断斯雷弗莱的命，恐怕你得面对一段漫长的旅途。好久不见了，葛丽特，你不是该在萨曼丁吗？为什么会来到这充满血腥的地方。无所谓，只要能杀了那家伙，便是要我的生命，也在所不惜！",},
{SDID = 3, actionState = 0,SDName = "战神",  		SDText = "无所谓，只要能杀了那家伙，便是要我的生命，也在所不惜！",},
{SDID = 4, actionState = 1,SDName = "波塞冬",  		SDText = "哈哈哈哈，现在的你早已不是有生命的活物了。由此一直向东，便能到达帝国的首都。",},
{SDID = 5, actionState = 1,SDName = "葛丽特",  		SDText = "你是谁？不是敌人就快来帮忙！",},
{SDID = 6, actionState = 0,SDName = "战神",  		SDText = "这点残余还是留给你吧，没兴趣和你争！",},
{SDID = 7, actionState = 1,SDName = "葛丽特",  		SDText = "奇怪，很熟悉的感觉……",},
{SDID = 8, actionState = 1,SDName = "斯雷弗莱",		SDText = "你是谁？",},
{SDID = 9, actionState = 1,SDName = "战神",  		SDText = "你的噩梦！",},
{SDID =10, actionState = 5,SDName = "雪莉",    		SDText = "好久不见了，葛丽特，你不是该在萨曼丁吗？为什么会来到这充满血腥的地方。",},
{SDID =11, actionState = 0,SDName = "葛丽特",  		SDText = "你也来到这里了不是吗？"},
{SDID =12, actionState = 1,SDName = "雪莉",    		SDText = "说的也是，身为国王，我必须守护我的民众。这里的妖魔不知受到什么东西的影响，变得非常狂暴，肆虐我的国家，我不得已才出面解决它们。",},
{SDID =13, actionState = 0,SDName = "雪莉",    		SDText = "伊斯特？久闻大名，这场战斗一定会很有趣的。",},
--关卡133  美杜莎受泰坦命令保护碎片
{SDID =14, actionState = 14,SDName = "美杜莎",  	SDText = "站住！什么人？",},
{SDID =15, actionState = 18,SDName = "雅典娜",  	SDText = "战神！【拳套碎片】就在她身上，蛇发女妖一族竟然和墨诺提俄斯勾结在了一起，看来这一路不会平静了。",},
{SDID =16, actionState = 10,SDName = "战神",  		SDText = "和这群长虫勾结在一起又能怎样！我只要能从她手里得到碎片就足够了。",},
{SDID =17, actionState = 14,SDName = "美杜莎",  	SDText = "做梦！这是墨诺提俄斯大人交给我保管的东西，你休想得到它！",},
{SDID =18, actionState = 10,SDName = "战神",  		SDText = "啊哈，这可由不得你。来吧，让我瞧瞧你的本事。",},
--关卡293 波塞冬的眼睛+宙斯电光链才能解除诅咒
{SDID =19, actionState = 16,SDName = "波塞冬",  	SDText = "战神，我们又见面了。",},
{SDID =20, actionState = 10,SDName = "战神",  		SDText = "波塞冬！身为海神却跑来冥界阻挠我，也好，我还怕你躲藏起来，哈哈哈！",},
{SDID =21, actionState = 16,SDName = "波塞冬",  	SDText = "【宙斯电光链】需要用我的眼睛才能获得力量解除你女儿的封印，我知道迟早会和你再有一战！",},
{SDID =22, actionState = 10,SDName = "战神",  		SDText = "不过是手下败将罢了！",},
{SDID =23, actionState = 16,SDName = "波塞冬",  	SDText = "狂妄的斯巴达人！很遗憾，我的力量早已不是你能比的，即便没有与墨诺提俄斯的约定，我也绝不会让你活着离开这条船。",},
{SDID =24, actionState = 10,SDName = "战神",  		SDText = "有趣！凭你的力量也想挡得住我，能办到的话就来试试吧！",},
--关卡111 对攻击预警进行说明
{SDID =25, actionState = 18,SDName = "雅典娜",  	SDText = "小心，那是一只强大的海妖，它的攻击强度非同小可。",},
{SDID =26, actionState = 18,SDName = "雅典娜",  	SDText = "看到了吗？这就是她要【发动强力攻击】的前奏，注意避开她的攻击范围。",},
{SDID =27, actionState = 10,SDName = "战神",  		SDText = "哼，一只海虫而已，抬抬手便可以收拾掉她！",},
--关卡121 战斗结束后剧情 泰坦抢走了纹章
{SDID =28, actionState = 17,SDName = "泰坦巨人",  	SDText = "战神，你休想进入烈火之狱！",},
{SDID =29, actionState = 17,SDName = "泰坦巨人",  	SDText = "【拳套碎片】我就收下了，哈哈哈！",},
{SDID =30, actionState = 10,SDName = "战神",  		SDText = "该死的，他是谁？",},
{SDID =31, actionState = 18,SDName = "雅典娜",  	SDText = "刚才那家伙是曾经被你击败的泰坦巨人厄庇墨透斯的弟弟——墨诺提俄斯。他很狡诈，必定会将碎片交给他的手下保管，你要怎么办？",},
{SDID =32, actionState = 10,SDName = "战神",  		SDText = "那还用说吗？不管是谁，我都要将他粉碎！",},
{SDID =33, actionState = 18,SDName = "雅典娜",  	SDText = "那就快追上去。放心，我会给你指引。",},
--关卡100 通过与雅典娜对白说明故事主线，并引出后续情节
{SDID =34, actionState = 18,SDName = "雅典娜",  	SDText = "战神，你终于来了。",},
{SDID =35, actionState = 10,SDName = "战神",  		SDText = "雅典娜！？你怎么在这里？是你说有打开冥界救我女儿的办法？",},
{SDID =36, actionState = 18,SDName = "雅典娜",  	SDText = "是的，你的女儿被囚禁在烈火之狱中，那是冥界最深最可怕的地方。只有染上了海怪许德拉之血的【尼米亚拳套】，才能打开冥界大门。",},
{SDID =37, actionState = 10,SDName = "战神",  		SDText = "那么，怎么才能得到【尼米亚拳套】？",},
{SDID =38, actionState = 18,SDName = "雅典娜",  	SDText = "我这里有【两块碎片】，如果你要的话，就来巨船中部找我，我现在无法脱身。",},
{SDID =39, actionState = 10,SDName = "战神",  		SDText = "我立刻就去！",},
--关卡111 废弃剧情XXXXXXXXXXXX
{SDID =40, actionState = 18,SDName = "雅典娜",  	SDText = "小心！看见这只海妖了吗，她拥有强大的攻击，XXXX",},
{SDID =41, actionState = 10,SDName = "战神",  	    SDText = "不管是谁阻挡我，都要成为我的刀下亡魂！XXX",},
--关卡112 通过剧情说明碎片的作用
{SDID =42, actionState = 18,SDName = "雅典娜",  	SDText = "等等，我感觉到了【尼米亚拳套碎片】就在这里。",},
{SDID =43, actionState = 10,SDName = "战神",  		SDText = "神器【尼米亚拳套】？",},
{SDID =44, actionState = 18,SDName = "雅典娜",  	SDText = "没错，只要集齐了全部的碎片便可以合成尼米亚拳套，你要尽快取得它。",},
--关卡121开场剧情
{SDID =45, actionState = 10,SDName = "战神",  		SDText = "这里应该就是巨船中部了，那就是你吗？",},
{SDID =46, actionState = 18,SDName = "雅典娜",  	SDText = "是的，因为我手中有【拳套碎片】，墨诺提俄斯一直意图抢夺，我只好藏身在这个塑像里了，可惜还是被他发现了。",},
{SDID =47, actionState = 10,SDName = "战神",  		SDText = "快把它交给我。",},
{SDID =48, actionState = 18,SDName = "雅典娜",  	SDText = "等等，这周围有埋伏的敌人，你先将它们驱散吧！",},
{SDID =49, actionState = 10,SDName = "战神",  		SDText = "哼，虫子们，来吧！",},
--关卡131开场说明第二块碎片
{SDID =50, actionState = 18,SDName = "雅典娜",  	SDText = "我感觉到了拳套的【第二块碎片】就在这附近，快去找到它。",},
{SDID =51, actionState = 10,SDName = "战神",  		SDText = "等我把这里清理干净再慢慢找也来得及。",},
--关卡141开场说明机关宝箱玩法
{SDID =52, actionState = 18,SDName = "雅典娜",  	SDText = "你要小心，附近到处都是【机关陷阱】，而且这里是暴虐的半人马盘踞的所在，他们是墨诺提俄斯的盟友，一定会想方设法要你的性命。",},
{SDID =53, actionState = 10,SDName = "战神",  		SDText = "就让我看看这些家伙有怎样的力量吧！",},
--关卡161山洞前剧情
{SDID =54, actionState = 10,SDName = "战神",  		SDText = "告诉我墨诺提俄斯在哪儿？",},
{SDID =55, actionState = 12,SDName = "半人马",  	SDText = "杀死战神！杀死战神！！",},
{SDID =56, actionState = 10,SDName = "战神",  		SDText = "真是不知死活。",},
{SDID =57, actionState = 12,SDName = "半人马",  	SDText = "族长命令，杀死战神！！",},
{SDID =58, actionState = 10,SDName = "战神",  		SDText = "那我就把你们的族长干掉好了！",},
--关卡163 半人马BOSS战剧情
{SDID =59, actionState = 10,SDName = "战神",  		SDText = "什么人？！",},
{SDID =60, actionState = 12,SDName = "半人马",  	SDText = "我是半人马族长凯龙，墨诺提俄斯与我族结盟，他的敌人便是我族的敌人。",},
{SDID =61, actionState = 10,SDName = "战神",  		SDText = "我会让你后悔与我作对。",},
{SDID =62, actionState = 12,SDName = "半人马",  	SDText = "即使你打败了我也没用的，我的族人正开启宙斯的封印，你将永远被这座岛束缚。",},
{SDID =63, actionState = 10,SDName = "战神",  		SDText = "那你就用死去的眼睛看我能不能从这里出去吧！",},
--关卡151 限时过关剧情
{SDID =64, actionState = 18,SDName = "雅典娜",  	SDText = "等一下，我在这里感受到了尼米亚拳套【最后的碎片】，应该是被半人马战士所保管。",},
{SDID =65, actionState = 10,SDName = "战神",  		SDText = "还是老做法，抢过来！",},
{SDID =66, actionState = 18,SDName = "雅典娜",  	SDText = "那么你的【动作要快】，否则半人马可能会把碎片转移地点。",},
{SDID =67, actionState = 18,SDName = "雅典娜",  	SDText = "注意，半人马已经封锁了道路。",},
{SDID =68, actionState = 18,SDName = "雅典娜",  	SDText = "看到了吗，在天上飞行的塞壬之子们会不断为敌人补充体力，如果不把它们先杀掉，恐怕很难迅速脱身。",},
{SDID =69, actionState = 10,SDName = "战神",  		SDText = "哈哈哈，这种举目皆敌的感觉真是让我热血沸腾，让我好好地杀个痛快！",},
--关卡171 开场剧情 引出乌狄尼
{SDID =70, actionState = 18,SDName = "雅典娜",  	SDText = "我们的船陷入了浅滩，无法行动。失控的半人马正在向这里扑过来，如果船被他们毁掉，一切都完了。",},
{SDID =71, actionState = 19,SDName = "乌狄妮",  	SDText = "战神，请交给我吧！我可以控制水流让海面升高，使船脱离浅滩，但是需要你全力阻止半人马闯进浅滩。",},
{SDID =72, actionState = 10,SDName = "战神",  		SDText = "这些杂碎就交给我了！",},
{SDID =73, actionState = 18,SDName = "雅典娜",  	SDText = "有了水精灵的帮助，我们就可以顺利离开这里了。",},
--关卡181 开场剧情 讲述乌狄尼来历，介绍护送玩法
{SDID =74, actionState = 19,SDName = "乌狄妮",  	SDText = "战神！",},
{SDID =75, actionState = 10,SDName = "战神",  		SDText = "乌狄妮，上次真是谢谢你了。",},
{SDID =76, actionState = 19,SDName = "乌狄妮",  	SDText = "我只是在报答你的恩情。当初你击败海皇波塞冬时，我就是被你所解救。",},
{SDID =77, actionState = 10,SDName = "战神",  		SDText = "还有那种事儿吗？我早就忘了。",},
{SDID =78, actionState = 19,SDName = "乌狄妮",  	SDText = "我知道墨诺提俄斯所前往的地方，请允许跟随你走一路。",},
{SDID =79, actionState = 10,SDName = "战神",  		SDText = "那好，我们现在就走吧。在找到那该死的家伙之前，我不会让那些杂碎碰你一根指头。",},
--关卡181 战斗结束 乌狄尼说出泰坦行踪，引出下张大地图雪山
{SDID =80, actionState = 10,SDName = "战神",  		SDText = "墨诺提俄斯那家伙去了哪儿？",},
{SDID =81, actionState = 19,SDName = "乌狄妮",  	SDText = "我看到了墨诺提俄斯从海上掠过的轨迹，他似乎正在准备前往冥界",},
{SDID =82, actionState = 10,SDName = "战神",  		SDText = "他想干什么？！",},
{SDID =83, actionState = 18,SDName = "雅典娜",  	SDText = "如果墨诺提俄斯提前进入冥界，你将再也无法找到他。而冥界之门也无法再次开启了。",},
{SDID =84, actionState = 10,SDName = "战神",  		SDText = "他既然想这么做，我要杀了他！",},
--关卡191 开场剧情介绍宙斯电光链
{SDID =85, actionState = 19,SDName = "乌狄妮",  	SDText = "战神，有件事情我要告诉你。你的女儿虽在冥界，却在冥界的封印之地。只有尼米亚拳套是不够的，还需要使用【宙斯电光链】打通前往封印之地的道路。",},
{SDID =86, actionState = 10,SDName = "战神",  		SDText = "你知道的竟然比雅典娜详细，但是又要去哪里找到它呢？",},
{SDID =87, actionState = 19,SDName = "乌狄妮",  	SDText = "【宙斯电光链】在众神之战中碎成了碎片，散落在了各处。其中一块被海怪许德拉吃掉了，除此之外的我就不清楚了。",},
{SDID =88, actionState = 10,SDName = "战神",  		SDText = "真是巧，我刚好要给这个家伙放放血。至于剩下的，就慢慢找吧。",},
--关卡193 BOSS战剧情，引出与波塞冬的冲突
{SDID =89, actionState = 15,SDName = "许德拉",  	SDText = "你就是战神吗？真是可怜的家伙。",},
{SDID =90, actionState = 10,SDName = "战神",  		SDText = "不过是条水虱子，敢挡在我的面前！",},
{SDID =91, actionState = 15,SDName = "许德拉",  	SDText = "难道还不知道这是让你死在此地的圈套？【宙斯电光链碎片】让我的力量增加了许多倍，现在的我的强大连自己都不敢相信。受海神波塞冬之命，这里就要变成你的死地。",},
{SDID =92, actionState = 10,SDName = "战神",  		SDText = "这里确实是死地，但却是你的！一切挡在我面前的家伙，都将是一样的下场！",},
{SDID =93, actionState = 15,SDName = "许德拉",  	SDText = "口出狂言的家伙，就让我来好好教训你吧！",},
--关卡201 引出雪山的统治者冰雪女王
{SDID =94, actionState = 19,SDName = "乌狄妮",  	SDText = "从这里开始，便是冥界的地域了。",},
{SDID =95, actionState = 10,SDName = "战神",  		SDText = "墨诺提俄斯来这里做什么？",},
{SDID =96, actionState = 19,SDName = "乌狄妮",  	SDText = "墨诺提俄斯试图夺取【宙斯电光链】的碎片，只有宙斯的力量加上海皇的天目，才能将你女儿身上的诅咒解除。",},
{SDID =97, actionState = 10,SDName = "战神",  		SDText = "就这么简单么？那好吧！",},
--关卡211 说明限时攻击玩法与原因 ---废弃
{SDID =98, actionState = 10,SDName = "战神",  		SDText = "宙斯神像怎么会在这里？",},
{SDID =99, actionState = 19,SDName = "乌狄妮",  	SDText = "墨诺提俄斯自然知晓你与宙斯之间的仇恨，把神像放在这里就是为了拖延时间。",},
{SDID =100, actionState = 10,SDName = "战神",  		SDText = "不管怎么说，我既然看到了就必须摧毁它！",},
{SDID =101, actionState = 19,SDName = "乌狄妮",  	SDText = "你的【动作要快】，时间拖得太久的话，可能就无法追上墨诺提俄斯了。",},
--关卡243 引发战神与美杜莎的冲突
{SDID =102, actionState = 14,SDName = "美杜莎",  	SDText = "战神，你这可恶的家伙。上次输给你，对我来说简直是奇耻大辱。",},
{SDID =103, actionState = 10,SDName = "战神",  		SDText = "只能怪你的头脑还不及你的眼睛更有用处。",},
{SDID =104, actionState = 14,SDName = "美杜莎",  	SDText = "闭嘴！这次我要让你体验什么叫做恐怖，对你的复仇才是我迄今为止的目的！",},
{SDID =105, actionState = 10,SDName = "战神",  		SDText = "你这满头蚯蚓的贱人！我要把你的头发一根根拔掉！",},
--关卡343 引发战神与链球怪的冲突
{SDID =106, actionState = 13,SDName = "链球怪",  	SDText = "战神！就是你……你是战神？！",},
{SDID =107, actionState = 10,SDName = "战神",  		SDText = "你就是西西弗斯吗？看你这愚蠢的样子。",},
{SDID =108, actionState = 13,SDName = "链球怪",  	SDText = "神器……斯巴达……墨诺提俄斯的心脏，解放……诅咒，……带我离开……烈火之狱。",},
{SDID =109, actionState = 10,SDName = "战神",  		SDText = "神器是指【哈迪斯钩爪】吗？",},
{SDID =110, actionState = 13,SDName = "链球怪",  	SDText = "杀死……战神！能获得……自由……不再……推石球。不再推……石球了！",},
{SDID =111, actionState = 10,SDName = "战神",  		SDText = "还是你这蠢货去死吧！",},
--关卡393 引发战神与泰坦巨人的冲突
{SDID =112, actionState = 17,SDName = "泰坦巨人",  	SDText = "战神！到此为止了！",},
{SDID =113, actionState = 10,SDName = "战神",  		SDText = "卑鄙的家伙，终于敢出现在我面前了吗？",},
{SDID =114, actionState = 17,SDName = "泰坦巨人",  	SDText = "这是智慧，你这野蛮的斯巴达人是不会理解的。",},
{SDID =115, actionState = 10,SDName = "战神",  		SDText = "听说要解除我女儿的诅咒需要使用【哈迪斯钩爪】吸取泰坦之心的精华，省得我去找你了，就在这里送给我吧！",},
{SDID =116, actionState = 17,SDName = "泰坦巨人",  	SDText = "是吗，可惜你的希望要落空了。在烈火之狱里，我的力量才能够完全发挥，而你，等死吧！",},
{SDID =117, actionState = 10,SDName = "战神",  		SDText = "就凭你那笨重的身躯，即使拥有再大的力量，也不会是我的对手。",},
{SDID =118, actionState = 17,SDName = "泰坦巨人",  	SDText = "真是狂妄，看我碾碎你！",},
{SDID =119, actionState = 10,SDName = "战神",  		SDText = "我不知道你从哪里来的自信，但是死得会是你！",},
--关卡221 宙斯电光链碎片掉落
{SDID =120, actionState = 19,SDName = "乌狄妮",  	SDText = "呼，这里越来越冷了。嗯？",},
{SDID =121, actionState = 19,SDName = "乌狄妮",  	SDText = "战神，这附近似乎有【宙斯电光链碎片】，我感受到了它的神力波动。",},
{SDID =122, actionState = 10,SDName = "战神",  		SDText = "在哪里？",},
{SDID =123, actionState = 19,SDName = "乌狄妮",  	SDText = "前面有座山洞，我想应该就在里面。",},
{SDID =124, actionState = 10,SDName = "战神",  		SDText = "那就快走吧。",},
--关卡222 后续接221
{SDID =125, actionState = 19,SDName = "乌狄妮",  	SDText = "呼~~~得救了，外面可真冷。现在我能确定，那块碎片就在这个洞穴的深处了。",},
{SDID =126, actionState = 10,SDName = "战神",  		SDText = "是吗，看起来我们的运气还不错。那我就一路扫荡过去，总会找到的。",},
--关卡251 关于宙斯电光链的作用，从这里开始物理攻击不起作用了
{SDID =127, actionState = 19,SDName = "乌狄妮",  	SDText = "战神。",},
{SDID =128, actionState = 10,SDName = "战神",  		SDText = "什么事？",},
{SDID =129, actionState = 19,SDName = "乌狄妮",  	SDText = "我需要提醒你，这里的怪物对物理攻击免疫，你需要拥有宙斯电光链或者哈迪斯钩爪才能对它们造成有效伤害。",},
{SDID =130, actionState = 10,SDName = "战神",  		SDText = "放心，我已经知道了。",},
--关卡161 开场剧情：已经得到了尼米亚拳套就可以离开火山岛了，前往冥界入口
{SDID =131, actionState = 18,SDName = "雅典娜",  	SDText = "战神，你已经得到了尼米亚拳套，是时候离开这里了。",},
{SDID =132, actionState = 10,SDName = "战神",  		SDText = "那可不行啊，这群可恶的半人马给泰坦充当走狗，必须要给他们点教训。",},
{SDID =133, actionState = 18,SDName = "雅典娜",  	SDText = "那你要怎么做？",},
{SDID =134, actionState = 10,SDName = "战神",  		SDText = "哼，去杀了这里的老大。",},
{SDID =135, actionState = 18,SDName = "雅典娜",  	SDText = "那就快点吧，没有太多时间让你悠闲了。",},
{SDID =136, actionState = 10,SDName = "战神",  		SDText = "不用你说，我知道怎么做。",},
--关卡301 进入了烈火之狱，随便扯两句
{SDID =137, actionState = 10,SDName = "战神",  		SDText = "刚刚还是冰天雪地，怎么这里会有这么多的火山？",},
{SDID =138, actionState = 19,SDName = "乌狄妮",  	SDText = "烈火之狱也叫混乱之地，这里的环境非常诡异，也许穿过一个山洞就会变成雪山。",},
{SDID =139, actionState = 10,SDName = "战神",  		SDText = "我的女儿竟然被墨诺提俄斯带到了这种地方，我一定要杀了他！",},
{SDID =140, actionState = 19,SDName = "乌狄妮",  	SDText = "在那之前还是小心一些，在这里我和雅典娜的智慧也无法帮忙了，后面就要靠你自己了。",},
{SDID =141, actionState = 10,SDName = "战神",  		SDText = "斯巴达的勇士，只会疯狂，小心是弱者的方式！",},
}

function DialogsNumber()	--剧情对话(ID数量)
	length = table.getn(StoryDialog)
	return length;
end

function DialogID(id)	--对话ID
	speakID = StoryDialog[id].SDID
	return speakID;
end

function DialogActionState(id)  ---cocoStudio剧情界面动画状态
	Rection = StoryDialog[id].actionState
	return Rection;
end

function DialogName(id) -- 对话人名
	speakName = StoryDialog[id].SDName
	return speakName;
end

function DialogText(id) --对话内容
	speakContent = StoryDialog[id].SDText
	return speakContent;
end

---颜色标识符 colorType 0【 , 1】
function ChangeColorBeginChar(colorType)
	if colorType == 0 then
		return "【";
	elseif colorType == 1 then
		return "】";
	end
	return "";
end

