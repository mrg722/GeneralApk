-----------序号(ID)	  名字      HP     MP   攻击   防御  暴击   闪避   挑战-奖励关卡  价钱	   类型  免费抽奖 钻石抽奖 套装ID(对象) 卖钱   说明
ResProperty = {
{ID=1,Name="生命药",		HP=500,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="可恢复500生命值",},
{ID=2,Name="能量药",		HP=0,MP=100, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="可恢复100能量值",},
{ID=3,Name="拳套碎片1",		HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="通关1-2获得",},
{ID=4,Name="拳套碎片2",		HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="通关1-4获得",},
{ID=5,Name="拳套碎片3",		HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="通关1-6获得",},
{ID=6,Name="电光链碎片1",	HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="通关1-10获得",},
{ID=7,Name="电光链碎片2",	HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="通关2-3获得",},
{ID=8,Name="电光链碎片3",	HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="金币、红魂副本掉落",},
{ID=9,Name="电光链碎片4",	HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="千层塔第22层宝箱",},
{ID=10,Name="电光链碎片5",	HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="每日签到第三天奖励",},
{ID=11,Name="电光链碎片6",	HP=0,MP=0, Att=0,Def=0,Crit=0,Miss=0,RewardGate=5,Price=800,Type=16, Free=3,Diamond=10,Suit=0,Sell=100,Information="第二章地图15星宝箱",},
}

function getResDataLength() --数组长度（物品个数）
	return table.getn(ResProperty);
end

function ResID(id) --物品ID
	resID = ResProperty[id].ID
	return resID;
end

function ResName(id) --物品名称
	resName = ResProperty[id].Name
	print(ResName)
	return resName;
end

function ResHP(id) --物品血量值	
	resHP = ResProperty[id].HP
	return resHP;
end

function ResMP(id) --物品能量值	
	resMP = ResProperty[id].MP
	return resMP;
end

function ResAtt(id) -- 物品攻击值	
	resAtt = ResProperty[id].Att
	return resAtt;
end

function ResDef(id) -- 物品防御值	
	resDef = ResProperty[id].Def
	return resDef;
end

function ResCrit(id) -- 物品暴击值	
	resCrit = ResProperty[id].Crit
	return resCrit;
end

function ResMiss(id) -- 物品闪避值	
	resMiss = ResProperty[id].Miss
	return resMiss;
end

function ResRewardGate(id) -- 物品奖励值	
	resRewardGate = ResProperty[id].RewardGate
	return resRewardGate;
end

function ResPrice(id) -- 物品价格值	
	resPrice = ResProperty[id].Price
	return resPrice;
end

function ResType(id)  -- 物品类型值	
	resType = ResProperty[id].Type
	return resType;
end

function ResFree(id)  -- 免费抽奖消费
	resFree = ResProperty[id].Free
	return resFree;
end
function ResDiamond(id)  -- 钻石抽奖消费
	resDiamond = ResProperty[id].Diamond
	return resDiamond;
end

function ResSuit(id)  -- 套装属性ID
	resSuit = ResProperty[id].Suit
	return resSuit;
end

function ResSell(id)  -- 出售价格
	resSell = ResProperty[id].Sell
	return resSell;
end

function ResInformation(id) -- 物品信息
	resInformation = ResProperty[id].Information
	return resInformation;
end
