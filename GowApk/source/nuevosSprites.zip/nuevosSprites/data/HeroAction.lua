-----------Type 主角 0基础武器 1 拳套武器 2 电光链 3 钩爪 脚本里填写字段顺序 0 1 2 3 4
HeroProperty = {
{Type = 0, BasicXML = 0,  InterXML1 = 5,  InterXML2 = 7,  SkillXML = 1,   UltimateSkillXML =86,},
{Type = 1, BasicXML = 9,  InterXML1 = 13, InterXML2 = 16, SkillXML = 87,  UltimateSkillXML =88,},
{Type = 2, BasicXML = 17, InterXML1 = 32, InterXML2 = 33, SkillXML = 105, UltimateSkillXML =106,},
{Type = 3, BasicXML = 34, InterXML1 = 36, InterXML2 = 40, SkillXML = 107, UltimateSkillXML =108,},
}

function getHeroDataLength() --数组长度（主角个数）
	return table.getn(HeroProperty);
end

--主角当前使用XML类型<HeroType武器类型 >  0基础武器 1 拳套武器 2 电光链 3 钩爪
--XMLType  乐堂编辑器精灵号类型
function getHeroCurrentXMLType(HeroType,XMLType) 	 
	if XMLType ==0  then
		return HeroProperty[HeroType].BasicXML
	elseif XMLType == 5 then
		return HeroProperty[HeroType].InterXML1
	elseif XMLType == 7 then
		return HeroProperty[HeroType].InterXML2
	elseif XMLType == 1  then
		return HeroProperty[HeroType].SkillXML	
	elseif XMLType == 86  then
		return HeroProperty[HeroType].UltimateSkillXML	
	end
	return -1;
end

