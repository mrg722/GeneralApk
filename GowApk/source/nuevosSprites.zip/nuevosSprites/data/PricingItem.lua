--region HuperziaData.lua
--Date 2015/12/17
--此文件由[BabeLua]插件自动生成

local item = {
	{rewardType = 1,	Name="VIP礼包",			HPBattle = 4,	MPBattle = 4, 	Money = 588, 		Souls = 5888,},		
	{rewardType = 2,	Name="药品礼包",		HPBattle = 25,	MPBattle = 25, 	Money = 0, 			Souls = 0,},	
	{rewardType = 3,	Name="获取金币",		HPBattle = 0,	MPBattle = 0, 	Money = 688, 		Souls = 0,},	
	{rewardType = 4,	Name="获取红魂",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 6888,},	
	{rewardType = 5,	Name="特价金币",		HPBattle = 0,	MPBattle = 0, 	Money = 2888, 		Souls = 0,},	
	{rewardType = 6,	Name="特价红魂",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 28888,},	
	{rewardType = 7,	Name="七日返现",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 0,},	
	{rewardType = 8,	Name="尼米亚拳套",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 0,},
	{rewardType = 9,	Name="宙斯电光链",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 0,},
	{rewardType = 10,	Name="哈迪斯钩爪",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 0,},
	{rewardType = 11,	Name="终极金币",		HPBattle = 0,	MPBattle = 0, 	Money = 18888, 		Souls = 0,},
	{rewardType = 12,	Name="终极红魂",		HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 188888,},	
	{rewardType = 13,	Name="新手礼包",		HPBattle = 7,	MPBattle = 7, 	Money = 275, 		Souls = 2100,},	
	{rewardType = 14,	Name="试用勾爪武器",	HPBattle = 0,	MPBattle = 0, 	Money = 0, 			Souls = 0,},
}

--计费点数据
--pringType  计费点类型
--priceRMB   计费点价格 <价格0 的为非计费点项, 价格小于0 为屏蔽项>
--rewardItem 计费点奖励类型 [[ rewardItem < 0 不奖励任何物品 ]]
local PricingItemData = {
{pringType = 1,	priceRMB = 28,	rewardItem = 1},
{pringType = 2,	priceRMB = 8,	rewardItem = 2},
{pringType = 3,	priceRMB = 6,	rewardItem = 3},
{pringType = 4,	priceRMB = 6,	rewardItem = 4},
{pringType = 5,	priceRMB = 22,	rewardItem = 5},
{pringType = 6,	priceRMB = 22,	rewardItem = 6},
{pringType = 7,	priceRMB = 28,	rewardItem = -1},
{pringType = 8,	priceRMB = 8,	rewardItem = -1},
{pringType = 9,	priceRMB = 18,	rewardItem = -1},
{pringType = 10,priceRMB = 28,	rewardItem = -1},
{pringType = 11,priceRMB = 98,	rewardItem = 11},
{pringType = 12,priceRMB = 98,	rewardItem = 12},
{pringType = 13,priceRMB = 0,	rewardItem = 13},
{pringType = 14,priceRMB = 0,	rewardItem = -1},
}

----获取 大额计费终极金币、终极红魂 显示动画状态<0 微信、支付宝2个按钮 1一个按钮>
--拇指玩	1
--金立		0
function getBigPricingRMBActionState()
	return 1;
end

--计费点总数
function getPricingNum()
	local num = table.getn(PricingItemData)
	return num;
end

---计费点类型
function getPricngType(id)
	p_type = PricingItemData[id].pringType
	return p_type;
end

--计费点名称
function getPricingName(id)
	local payName = item[id].Name
	return payName;
end

---计费点价格
function getPricngPriceRMB(id)
	price_RMB = PricingItemData[id].priceRMB
	return price_RMB;
end

---计费点奖励类型
function getPricngRewardItem(id ,rewardItemType)
	local itemType = PricingItemData[id].rewardItem --当前计费点选择的奖励类型
	if itemType < 0 then
		return 0;
	end
	
	local rewardNum = 0;
	if rewardItemType == 0 then 
		rewardNum = item[itemType].HPBattle  ---生命药数量
	elseif 	rewardItemType == 1 then 
		rewardNum = item[itemType].MPBattle  --能量药数量
	elseif 	rewardItemType == 2 then 
		rewardNum = item[itemType].Money     --金币数量
	elseif 	rewardItemType == 3 then 
		rewardNum = item[itemType].Souls     --红魂数量
	end	
	return rewardNum;
end


--endregion

