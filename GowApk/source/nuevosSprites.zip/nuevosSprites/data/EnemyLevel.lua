CommondEnemyLevel = {
{ID = 101,	Level = 1,},
{ID = 111,	Level = 2,},
{ID = 121,	Level = 4,},
{ID = 131,	Level = 6,},
{ID = 141,	Level = 8,},
{ID = 151,	Level = 10,},
{ID = 161,	Level = 12,},
{ID = 171,	Level = 14,},
{ID = 181,	Level = 17,},
{ID = 191,	Level = 20,},

{ID = 201,	Level = 20,},
{ID = 211,	Level = 25,},
{ID = 221,	Level = 30,},
{ID = 231,	Level = 35,},
{ID = 241,	Level = 40,},
{ID = 251,	Level = 15,},
{ID = 261,	Level = 20,},
{ID = 271,	Level = 25,},
{ID = 281,	Level = 30,},
{ID = 291,	Level = 35,},

{ID = 301,	Level = 40,},
{ID = 311,	Level = 45,},
{ID = 321,	Level = 50,},
{ID = 331,	Level = 55,},
{ID = 341,	Level = 60,},
{ID = 351,	Level = 45,},
{ID = 361,	Level = 55,},
{ID = 371,	Level = 65,},
{ID = 381,	Level = 75,},
{ID = 391,	Level = 99,},
}

HuperziaEnemyLevel = {
{ID = 901,	Level = 10,},
{ID = 902,	Level = 12,},
{ID = 903,	Level = 14,},
{ID = 904,	Level = 16,},
{ID = 905,	Level = 18,},
{ID = 906,	Level = 20,},
{ID = 907,	Level = 22,},
{ID = 908,	Level = 24,},
{ID = 909,	Level = 26,},
{ID = 910,	Level = 28,},
{ID = 911,	Level = 30,},
{ID = 912,	Level = 32,},
{ID = 913,	Level = 34,},
{ID = 914,	Level = 36,},
{ID = 915,	Level = 38,},
{ID = 916,	Level = 40,},
{ID = 917,	Level = 42,},
{ID = 918,	Level = 44,},
{ID = 919,	Level = 46,},
{ID = 920,	Level = 48,},
{ID = 921,	Level = 30,},
{ID = 922,	Level = 33,},
{ID = 923,	Level = 36,},
{ID = 924,	Level = 39,},
{ID = 925,	Level = 42,},
{ID = 926,	Level = 45,},
{ID = 927,	Level = 48,},
{ID = 928,	Level = 51,},
{ID = 929,	Level = 54,},
{ID = 930,	Level = 57,},
{ID = 931,	Level = 60,},
{ID = 932,	Level = 63,},
{ID = 933,	Level = 66,},
{ID = 934,	Level = 69,},
{ID = 935,	Level = 72,},
{ID = 936,	Level = 50,},
{ID = 937,	Level = 54,},
{ID = 938,	Level = 58,},
{ID = 939,	Level = 62,},
{ID = 940,	Level = 66,},
{ID = 941,	Level = 70,},
{ID = 942,	Level = 74,},
{ID = 943,	Level = 78,},
{ID = 944,	Level = 82,},
{ID = 945,	Level = 86,},
{ID = 946,	Level = 90,},
{ID = 947,	Level = 94,},
{ID = 948,	Level = 98,},
{ID = 949,	Level = 102,},
{ID = 950,	Level = 106,},
}

--通过当前关卡号 自动匹配 对应的敌人等级数值
function getEnemyName(gate,heroLevel)	
	local level = 0;
	if gate == 100 then
		level = 1;
	elseif gate < 700 then	---普通副本
		local integerNum,decimals =  math.modf((gate % 100) / 10 );--取一个数的整数 小数 <计算各位>
		local integerNum1,decimals1 =  math.modf(gate / 100); -- <计算十位>
		gateID =  integerNum + (integerNum1 -1) * 10 + 1;
		level = CommondEnemyLevel[gateID].Level;
	elseif gate < 900 then ---副本<金币、红魂关卡>
		level = heroLevel;
	else ---千层塔关卡
		gateID =(gate % 900);
		level = HuperziaEnemyLevel[gateID].Level
	end
	
	--local randomNum = math.random(0,1); --随机生成敌人等级浮动
	--level = level+randomNum
	return level;
end 

