
------关卡号, 任务名1，任务名2，任务名3
TaskName = {
{GateID=101,Name1="消灭全,部敌人",			Name2="达成,连击数",				Name3="完成,本关",},
{GateID=111,Name1="QTE,杀敌",				Name2="完成,二段跳",				Name3="",},
{GateID=112,Name1="精英,骷髅兵",			Name2="",							Name3="",},
{GateID=121,Name1="袭来的,敌人",			Name2="守护,雅典娜",				Name3="",},
{GateID=122,Name1="精英,钻地怪",			Name2="",							Name3="",},
{GateID=131,Name1="消灭,象怪",				Name2="",							Name3="",},
{GateID=132,Name1="使用,机关",				Name2="",							Name3="",},
{GateID=133,Name1="精英,美杜莎",			Name2="",							Name3="",},
{GateID=141,Name1="开启,宝箱",				Name2="不受地,火攻击",				Name3="",},
{GateID=142,Name1="精英,半人马",			Name2="",							Name3="",},
{GateID=151,Name1="消灭全,部敌人",			Name2="开启,宝箱",					Name3="精英,半人马",},
{GateID=161,Name1="半人马,守卫",			Name2="",							Name3="",},
{GateID=162,Name1="消灭,钻地怪",			Name2="",							Name3="",},
{GateID=163,Name1="击杀,BOSS",				Name2="",							Name3="",},
{GateID=171,Name1="达成,连击数",			Name2="",							Name3="",},
{GateID=172,Name1="受攻击,次数",			Name2="精英,敌人",					Name3="",},
{GateID=181,Name1="护送,乌狄妮",			Name2="埋伏的,敌人",				Name3="精英,美杜莎",},
{GateID=191,Name1="精英,美杜莎",			Name2="",							Name3="",},
{GateID=192,Name1="消灭,盾牌兵",			Name2="",							Name3="",},
{GateID=193,Name1="击杀,许德拉 ",			Name2="",							Name3="",},

{GateID=201,Name1="精英,象怪",				Name2="受攻击,次数",				Name3="",},
{GateID=202,Name1="消灭全,部敌人",			Name2="",							Name3="",},
{GateID=211,Name1="摧毁,神像",				Name2="使用,技能",					Name3="",},
{GateID=212,Name1="消灭,盾牌兵",			Name2="",							Name3="",},
{GateID=221,Name1="消灭,钻地怪",			Name2="",							Name3="",},
{GateID=222,Name1="钻地怪,统领",			Name2="消耗,生命药",				Name3="",},
{GateID=231,Name1="达成,连击数",			Name2="",							Name3="",},
{GateID=232,Name1="开启,宝箱",				Name2="不受地,刺攻击",				Name3="",},
{GateID=241,Name1="受攻击,次数",			Name2="",							Name3="",},
{GateID=242,Name1="精英,敌人 ",				Name2="",							Name3="",},
{GateID=243,Name1="击杀,BOSS",				Name2="",							Name3="",},
{GateID=251,Name1="精英,美杜莎",			Name2="",							Name3="",},
{GateID=252,Name1="消灭全,部敌人",			Name2="达成,连击数",				Name3="",},
{GateID=261,Name1="消灭全,部敌人",			Name2="开启,宝箱",					Name3="受攻击,次数",},
{GateID=271,Name1="开启,船舱",				Name2="",							Name3="",},
{GateID=272,Name1="消灭,美杜莎",			Name2="",							Name3="",},
{GateID=273,Name1="美杜莎,统领",			Name2="",							Name3="",},
{GateID=281,Name1="消灭,象怪",				Name2="",							Name3="",},
{GateID=282,Name1="精英,敌人",				Name2="守护,神像",					Name3="",},
{GateID=291,Name1="消灭全,部敌人",			Name2="",							Name3="",},
{GateID=292,Name1="消灭,美杜莎",			Name2="",							Name3="",},
{GateID=293,Name1="击杀,波塞冬",			Name2="",							Name3="",},

{GateID=301,Name1="消灭,骷髅兵",			Name2="",							Name3="",},
{GateID=302,Name1="链球怪,统领",			Name2="消耗,生命药",				Name3="",},
{GateID=311,Name1="精英,敌人",				Name2="",							Name3="",},
{GateID=312,Name1="护送,乌狄妮",			Name2="象怪,统领",					Name3="",},
{GateID=321,Name1="达成,连击数 ",			Name2="",							Name3="",},
{GateID=322,Name1="链球怪,统领",			Name2="受攻击,次数",				Name3="",},
{GateID=331,Name1="半人马,统领",			Name2="精英,敌人",					Name3="消耗,生命药",},
{GateID=341,Name1="钻地怪,统领",			Name2="",							Name3="",},
{GateID=342,Name1="半人马,统领",			Name2="",							Name3="",},
{GateID=343,Name1="击杀,BOSS",				Name2="",							Name3="",},
{GateID=351,Name1="消灭,象怪",				Name2="",							Name3="",},
{GateID=352,Name1="美杜莎,统领",			Name2="达成,连击数",				Name3="",},
{GateID=361,Name1="达成,连击数",			Name2="",							Name3="",},
{GateID=362,Name1="开启,宝箱",				Name2="不受地,刺攻击",				Name3="",},
{GateID=371,Name1="消灭,骷髅兵",			Name2="",							Name3="",},
{GateID=372,Name1="使用,机关",				Name2="半人马,统领",				Name3="",},
{GateID=381,Name1="精英,敌人",				Name2="达成,连击数",				Name3="",},
{GateID=382,Name1="摧毁,神像",				Name2="",							Name3="",},
{GateID=391,Name1="受攻击,次数",			Name2="",							Name3="",},
{GateID=392,Name1="半人马,统领",			Name2="",							Name3="",},
{GateID=393,Name1="击杀,BOSS",				Name2="",							Name3="",},
}

---获得任务关卡号
function getCurrentGate(id)
	ID = TaskName[id].GateID
	return ID;
end

---获得任务1名称
function getTaskName1(id)
	name = TaskName[id].Name1
	return name;
end

---获得任务2名称
function getTaskName2(id)
	name = TaskName[id].Name2
	return name;
end

---获得任务2名称
function getTaskName3(id)
	name = TaskName[id].Name3
	return name;
end
--endregion
