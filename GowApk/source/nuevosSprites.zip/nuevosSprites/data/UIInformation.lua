--actionState(0--N,UI编辑器内状态号)
InformationText = {
{SDID = 1,SDText = "该武器的碎片尚未集齐。",},--点击“碎片解锁”按钮（碎片尚未集齐的情况下）
{SDID = 2,SDText = "武器升级失败。",},--点击升级按钮（在满足升级条件但武器升级失败的情况下）
{SDID = 3,SDText = "武器等级不能高于技能等级10级以上",},--点击升级按钮（在不满足升级武器所需的技能等级的情况下）
{SDID = 4,SDText = "需要达到三星才能扫荡",},--点击扫荡、扫荡5次两个按钮（在玩家此关卡星级未达三星的情况下）
{SDID = 5,SDText = "VIP开启扫荡5次功能",},--点击扫荡5次按钮（在非VIP玩家点击扫荡5次按钮的情况下）
{SDID = 6,SDText = "您已经是VIP了",},--点击“成为VIP！”按钮（在VIP玩家点击“成为VIP！”按钮的情况下）
}
---获得界面高级控件提示文字信息ID
function getInformationTextID(id)
	textID = InformationText[id].SDID
	return textID
end
---获得界面高级控件提示文字信息内容
function getUIInformationText(id)
	text = InformationText[id].SDText
	return text
end

function getFiveLvUpInfomation(successTimes,failedTimes,subSouls)
	local str = "成功"..successTimes.."次，".."失败"..failedTimes.."次，消耗"..subSouls.."红魂。"
	return str;
end
