--region preLoadingCSBFile.lua
--Date 2015/12/17
--此文件由[BabeLua]插件自动生成

---  渠道KEY <开关>
---- 当前渠道ID <警告：此值必须大于0> ,设置ChanelData里的chanelType为哪个渠道
---当前渠道显示的帮助、关于文本内容
AboutAndHelpText = {
	{--对应chanelType = 1
	    chanelText = "\n游戏名称:战神之刃\n开发商：北京元火科技有限公司\n\n官方投诉通道\n客服电话：15510049944\n客服QQ：1457835272\n客服邮箱：king86kefu@163.com\n工作时间：9:00—18:00\n\n操作说明\n屏幕左下：移动方向摇杆（左右）\n屏幕右下：普通攻击、技能	\n屏幕左上：点选进入主菜单界面\n其余按钮：点击即可实现其功能\n\n魔防怪免疫物攻；物防怪免疫魔攻。\n哈迪斯钩爪同时具有物魔攻。\n千层塔宝箱奖励、挑战次数每晚12点\n刷新，当天积分清零。\n战斗准备购买的BUFF只在本次战斗中\n起效。\n神秘宝箱产生的BUFF只最后一个起效。\n",
    },
	{--对应chanelType = 2
	    chanelText = "\n游戏名称:战神之刃\n开发商：北京元火科技有限公司\n\n官方投诉通道\n客服电话：15510049944\n客服QQ：1457835272\n客服邮箱：king86kefu@163.com\n工作时间：9:00—18:00\n\n免责声明\n本游戏版权归北京元火科技有限公司\n所有，游戏中的文字、图片等内容均\n为游戏版权所有者的个人态度或立场，\n炫彩互动（中国电信）对此不承担任\n何法律责任。\n\n操作说明\n屏幕左下：移动方向摇杆（左右）\n屏幕右下：普通攻击、技能	\n屏幕左上：点选进入主菜单界面\n其余按钮：点击即可实现其功能\n\n魔防怪免疫物攻；物防怪免疫魔攻。\n哈迪斯钩爪同时具有物魔攻。\n千层塔宝箱奖励、挑战次数每晚12点\n刷新，当天积分清零。\n战斗准备购买的BUFF只在本次战斗中\n起效。\n神秘宝箱产生的BUFF只最后一个起效。\n",
    },
}


	
---chanelType 渠道类型 , chanelName  渠道名称 ,MoreGame  更多游戏, CDKEY 兑换码 ,Fornm 论坛 , Service 客服 < >
-----<1 为对应按钮显示, 否则不显示即0 > 
------[[先后顺序不可修改]]
ChanelData = {
	{chanelType = 1, chanelName = "MM",  		MoreGame = 0, CDKEY = 0, Fornm = 0, Service = 0,AboutAndHelp = 1},
	{chanelType = 2, chanelName = "联通", 	 	MoreGame = 0, CDKEY = 0, Fornm = 0, Service = 0,AboutAndHelp = 1},
	{chanelType = 3, chanelName = "电信", 		MoreGame = 0, CDKEY = 0, Fornm = 0, Service = 0,AboutAndHelp = 1},	
	{chanelType = 4, chanelName = "移动",  		MoreGame = 0, CDKEY = 0, Fornm = 0, Service = 0,AboutAndHelp = 1},	
	{chanelType = 5, chanelName = "拇指玩",  	MoreGame = 0, CDKEY = 0, Fornm = 0, Service = 0,AboutAndHelp = 1},
}

function getPriceDataLength() --数组长度（渠道个数）
  return table.getn(ChanelData)
end

---对应渠道按钮屏蔽、显示逻辑
function getButtonVisible(buttonType,CurrentChanelID)	
	if 		buttonType == 0 and ChanelData[CurrentChanelID].MoreGame 	== 1 then --更多游戏
		return true
		
	elseif buttonType == 1 and ChanelData[CurrentChanelID].CDKEY 		== 1 then --兑换码
		return true
		
	elseif buttonType == 2 and ChanelData[CurrentChanelID].Fornm 		== 1 then --论坛
		return true
		
	elseif buttonType == 3 and ChanelData[CurrentChanelID].Service 		== 1 then --客服
		return true
	end
	return false
end

--对应渠道帮助关于显示文本
function getChanelAboutAndHelp(CurrentChanelID)
	local helpType = ChanelData[CurrentChanelID].AboutAndHelp
	local helpText = AboutAndHelpText[helpType].chanelText
	return helpText;
end

---第一屏是否显示渠道Logo <true 显示，false 不显示>
function isShowChanelLogo()
	return true;
end
--endregion

