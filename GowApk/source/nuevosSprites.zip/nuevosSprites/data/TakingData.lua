
local GameCurrencyRewardData = {
{ID=1,	currencyType="101关卡首次通关奖励",},
{ID=2,	currencyType="新手礼包奖励",},
{ID=3,	currencyType="离线奖励",},
{ID=4,	currencyType="每日签到奖励",},
{ID=5,	currencyType="VIP每日签到奖励",},
{ID=6,	currencyType="在线奖励",},
{ID=7,	currencyType="VIP礼包奖励",},
{ID=8,	currencyType="战斗中宝箱奖励",},
{ID=9,	currencyType="扫荡奖励",},
{ID=10,	currencyType="周卡每日金币奖励",},
{ID=11,	currencyType="周卡宝箱奖励",},
{ID=12,	currencyType="普通关卡星级宝箱",},
{ID=13,	currencyType="红魂副本红魂奖励",},
{ID=14,	currencyType="金币副本金币奖励",},
{ID=15,	currencyType="怪物掉落",},
{ID=16,	currencyType="千层塔宝箱",},
{ID=17,	currencyType="普通关卡掉落",},
{ID=18,	currencyType="收益Buff奖励",},
}

local GameCurrencySubData = {
{ID=1,	currencyType="离线消耗金币",},
{ID=2,	currencyType="武器消耗红魂",},
{ID=3,	currencyType="武器消耗金币",},
{ID=4,	currencyType="技能消耗金币",},
{ID=5,	currencyType="技能消耗红魂",},
{ID=6,	currencyType="千层塔再次挑战",},
{ID=7,	currencyType="扫荡消耗金币",},
{ID=8,	currencyType="战前准备消耗金币",},
{ID=9,	currencyType="战前准备消耗红魂",},
}

local GameVirtualCurrencySubData = {
{ID=1,	currencyType="离线奖励",},
{ID=2,	currencyType="武器升级",},
{ID=3,	currencyType="技能升级",},
{ID=4,	currencyType="千层塔再次挑战",},
{ID=5,	currencyType="扫荡",},
{ID=6,	currencyType="战前准备Buff",},
}

--游戏奖励货币名称
function getGameRewardMoney(id)	
	local moneyType = GameCurrencyRewardData[id].currencyType
	return moneyType;
end

--游戏消耗货币名称
function getGameSubMoney(id)
	local moneyType = GameCurrencySubData[id].currencyType
	return moneyType;
end

--TakingData虚拟游戏币消耗名称
function getGameVirtualCurrencySub(id)
	local moneyType = GameVirtualCurrencySubData[id].currencyType
	return moneyType;
end