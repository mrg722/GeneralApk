lenrow = 1
lenline = 8
data = {
{7,0,260,10,1,0,1,0,},
}
