lenrow = 1
lenline = 8
data = {
{7,0,450,10,1,0,1,0,},
}
